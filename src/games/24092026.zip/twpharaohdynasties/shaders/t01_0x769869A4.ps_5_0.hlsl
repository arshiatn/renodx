// PHARAOH t01 - hdr_to_screen. MSAA is a runtime branch here (both gbuffer textures
// bound, g_num_of_samples picks), and god rays / glow branch on their own strengths, so
// none of those are permutation axes. DOF and distortion still look like separate ones.
//
// Multipliers: SI.godrays, SI.bloom, SI.filmgrain.
//
// HDR mode 1 = faithful (unclipped stock curve -> user grading -> peak shoulder),
//     mode 2 = PsychoV30. Both bridge colour_matrix + LUT through a bounded gamma proxy.
// HDR assumes in-game Brightness 10 and Gamma 22 and ignores the cbuffer. SDR keeps
// using the live values, so it is unaffected.
//
// Two decompiler bugs corrected below - see the ### CORRECTED ### notes.

cbuffer colorimetry_VS_PS : register(b0)
{
  float g_brightness : packoffset(c0);
  float g_gamma_output : packoffset(c0.y);
  float g_inv_gamma_output : packoffset(c0.z);
}

cbuffer camera : register(b1)
{
  float3 camera_position : packoffset(c0);
  float4x4 view : packoffset(c1);
  float4x4 projection : packoffset(c5);
  float4x4 view_projection : packoffset(c9);
  float4x4 inv_view : packoffset(c13);
  float4x4 inv_projection : packoffset(c17);
  float4x4 inv_view_projection : packoffset(c21);
  float4 camera_near_far : packoffset(c25);
  float time_in_sec : packoffset(c26);
  float2 g_inverse_focal_length : packoffset(c26.y);
  float g_vertical_fov : packoffset(c26.w);
  float4 g_screen_size : packoffset(c27);
  float g_vpos_texel_offset : packoffset(c28);
  float4 g_viewport_dimensions : packoffset(c29);
  float2 g_viewport_origin : packoffset(c30);
  float4 g_render_target_dimensions : packoffset(c31);
  float4 g_camera_temp0 : packoffset(c32);
  float4 g_camera_temp1 : packoffset(c33);
  float4 g_camera_temp2 : packoffset(c34);
  float4 g_clip_rect : packoffset(c35);
  float3 g_vr_head_rotation : packoffset(c36);
  int g_num_of_samples : packoffset(c36.w);
  float g_supersampling : packoffset(c37);
  float4 g_mouse_position : packoffset(c38);
  float3 g_frustum_points[8] : packoffset(c39);
  float g_orthographic : packoffset(c46.w);
  float g_overlay_lerp : packoffset(c47);
  float g_overlay_text_lerp : packoffset(c47.y);
  float g_overlay_parchment_lerp : packoffset(c47.z);
  float g_overlay_palette_alpha : packoffset(c47.w);
  float4 g_overlay_outline_colour : packoffset(c48);
  float g_overlay_outline_border_width : packoffset(c49);
  float g_ui_overlay_brightness : packoffset(c49.y);
  float g_debug_tonemapping : packoffset(c49.z);
  float4 g_blood_remap : packoffset(c50);
  int g_editor_mode : packoffset(c51);
  float4 g_spec_gloss_tweaker : packoffset(c52);
}

cbuffer lighting_VS_PS : register(b2)
{
  bool g_apply_environment_specular : packoffset(c0);
  bool g_contact_shadows : packoffset(c0.y);
  float3 sun_direction : packoffset(c1);
  float3 sun_disk_direction : packoffset(c2);
  float3 sun_colour : packoffset(c3);
  float3 sun_colour_unscaled : packoffset(c4);
  float2 sun_angular_radius : packoffset(c5);
  float sky_colour_scale : packoffset(c5.z);
  float3 ambient_cube_lr[2] : packoffset(c6);
  float3 ambient_cube_tb[2] : packoffset(c8);
  float3 ambient_cube_fb[2] : packoffset(c10);
  float3 g_deep_water_colour : packoffset(c12);
  float3 g_shallow_water_colour : packoffset(c13);
  float3 g_sea_bed_light_scatter : packoffset(c14);
  int g_ssr_enabled : packoffset(c14.w);
  float2 g_cloud_shadow_position : packoffset(c15);
  float g_cloud_shadow_scale : packoffset(c15.z);
  float2 g_cloud_shadow_lerp : packoffset(c16);
  float3 g_cloud_shadow_tiling_params : packoffset(c17);
  float2 g_noise_uv_shift : packoffset(c18);
  float2 g_skin_curvature_scale_bias : packoffset(c18.z);
  float2 g_skin_translucency_scale_bias : packoffset(c19);
  float3 g_skin_blood_colour : packoffset(c20);
  float4 g_world_bounds : packoffset(c21);
  float4 g_water_plane_bounds : packoffset(c22);
  float4 g_playable_area_bounds : packoffset(c23);
  float g_vegetation_wrap_lighting_bias : packoffset(c24);
  float g_spherical_harmonic_terms : packoffset(c24.y);
  float g_spherical_harmonic_fadeout : packoffset(c24.z);
  float g_debug_puddle_map : packoffset(c24.w);
  float g_debug_white_diffuse : packoffset(c25);
  float g_debug_light_diffuse_coef : packoffset(c25.y);
  float g_debug_light_ambient_coef : packoffset(c25.z);
  float g_debug_light_specular_coef : packoffset(c25.w);
  float g_debug_light_shadow_coef : packoffset(c26);
  float g_light_vegetation_backscattering_coef : packoffset(c26.y);
  float g_debug_light_bs_coef2 : packoffset(c26.z);
  float g_borders_colour_scale : packoffset(c26.w);
  float g_water_caustics_scale : packoffset(c27);
  float g_water_specular_scale : packoffset(c27.y);
  float g_campaign_water_attrition_strength : packoffset(c27.z);
  float g_water_light_scattering : packoffset(c27.w);
  float g_water_light_scattering_battle_rivers : packoffset(c28);
  float g_dynamic_light_scale : packoffset(c28.y);
  float4 g_skybox_cylinder_params : packoffset(c29);
  float4 g_fog_cell_shading : packoffset(c30);
  float2 g_aristeia_pos : packoffset(c31);
  float4 g_aristeia_effect : packoffset(c32);
  float g_campaign_flat_map : packoffset(c33);
  bool g_interactive_water_enabled : packoffset(c33.y);
  float4 g_interactive_water_bounds : packoffset(c34);
  float4 g_rain_camera_position : packoffset(c35);
  float4 g_rain_camera_mat_col1 : packoffset(c36);
  float4 g_rain_camera_mat_col2 : packoffset(c37);
  float4 g_rain_camera_mat_col3 : packoffset(c38);
  float4 g_rain_direction : packoffset(c39);
  float4 g_rain_color : packoffset(c40);
  float4 g_rain_lightning : packoffset(c41);
  float4 g_rain_puddles_params : packoffset(c42);
  float4 g_sky_correction_colour : packoffset(c43);
  float g_sky_correction_contrast : packoffset(c44);
  float g_sky_correction_brightness : packoffset(c44.y);
  float4 g_nile_colour : packoffset(c45);
  float g_nile_flow_speed : packoffset(c46);
  float4 g_puddle_map_bounds : packoffset(c47);
  int g_high_quality_puddle_sampling : packoffset(c48);
  float2 g_world_height_bounds : packoffset(c48.y);
  float4 g_screen_space_shadows_parameters : packoffset(c49);
  float g_generating_light_probe : packoffset(c50);
  int g_screen_space_shadows_step_count : packoffset(c50.y);
  int g_screen_space_environment_occlusion_quality : packoffset(c50.z);
  int g_screen_space_environment_occlusion_step_count : packoffset(c50.w);
  float g_screen_space_environment_occlusion_max_trace_distance : packoffset(c51);
  float2 g_screen_space_environment_smoothness_bounds : packoffset(c51.y);
  float2 g_nile_map_offset : packoffset(c52);
}

cbuffer fog : register(b3)
{
  float g_fog_density_constant : packoffset(c0);
  float g_fog_density_height : packoffset(c0.y);
  float g_fog_height_bottom : packoffset(c0.z);
  float g_fog_height_top : packoffset(c0.w);
  float3 g_fog_noise_position : packoffset(c1);
  float g_fog_density_mie : packoffset(c1.w);
  float g_fog_noise : packoffset(c2);
  float3 g_fog_colour : packoffset(c2.y);
  uint g_fog_mode : packoffset(c3);
  float g_fog_lerp : packoffset(c3.y);
  float g_fog_clear_distance : packoffset(c3.z);
  float g_fog_y_multiplier : packoffset(c3.w);
  float g_campaign_density_scaling : packoffset(c4);
  float g_height_fog_clear_distance : packoffset(c4.y);
  float g_clear_distance_fade_out : packoffset(c4.z);
  float g_fog_far_skybox_lerp : packoffset(c4.w);
  float g_fog_far_skybox_mip : packoffset(c5);
  float2 g_fog_shadow_strength : packoffset(c5.y);
  float g_fog_blur_offset : packoffset(c5.w);
  float g_fog_blur_strength : packoffset(c6);
  float3 g_height_fog_colour : packoffset(c6.y);
  float g_height_fog_falloff : packoffset(c7);
  float g_height_fog_clear_falloff : packoffset(c7.y);
  float g_height_fog_forward_scattering : packoffset(c7.z);
  float2 g_campaign_map_size : packoffset(c8);
  float3 g_rayleigh_density : packoffset(c9);
  float g_atmosphere_height_multiplier : packoffset(c9.w);
  float g_atmosphere_bottom : packoffset(c10);
  float g_sun_disc_color_scale : packoffset(c10.y);
  float g_sun_scale : packoffset(c10.z);
  float g_fog_resolution : packoffset(c10.w);
  float g_height_occlusion : packoffset(c11);
  float g_density_sum : packoffset(c11.y);
  float g_skybox_size : packoffset(c11.z);
}

cbuffer shared_fog_of_war_PS : register(b4)
{
  float g_fog_of_war_blend : packoffset(c0);
  float g_fog_of_war_outfield_blend : packoffset(c0.y);
}

cbuffer hdr_to_screen_PS : register(b5)
{
  int rain_planes_count : packoffset(c0);
  float radial_blur_strength : packoffset(c0.y);
  float2 radial_blur_position : packoffset(c0.z);
  float scene_max_distance : packoffset(c1);
  float focus_distance : packoffset(c1.y);
  float focal_length : packoffset(c1.z);
  float blur_kernel_scale : packoffset(c1.w);
  float4x4 colour_matrix : packoffset(c2);
  float4 pos_transform : packoffset(c6);
  float overscan : packoffset(c7);
  float god_rays_strength : packoffset(c7.y);
  float2 glow_strength : packoffset(c7.z);
  float glow_depth_masking : packoffset(c8);
  float post_processing_strength : packoffset(c8.y);
  float lut_strength : packoffset(c8.z);
  float3 grain_tex_offset_enabled : packoffset(c9);
}

SamplerState s_shroud_clouds_s : register(s0);
SamplerState s_fog_of_war_mask_s : register(s1);
SamplerState frame_sampler_s : register(s2);
SamplerState lut_sampler_s : register(s3);
SamplerState god_rays_sampler_s : register(s4);
SamplerState glow_sampler_s : register(s5);
SamplerState grain_sampler_s : register(s6);
SamplerState rain_sampler_s : register(s7);
Texture2DMS<float4> gbuffer_channel_4_texture_ms : register(t0);
Texture2D<float4> gbuffer_channel_4_texture : register(t1);
Texture2D<float4> t_shroud_clouds : register(t2);
Texture2D<float4> t_fog_of_war_mask : register(t3);
Texture2D<float4> frame_texture : register(t4);
Texture3D<float4> lut_texture : register(t5);
Texture2D<float4> god_rays_texture : register(t6);
Texture2D<float4> glow_texture1 : register(t7);
Texture2D<float4> grain_texture : register(t8);
Texture2D<float4> rain_texture : register(t9);


// 3Dmigoto declarations
#define cmp -
#include "../shared.h"
#include "../psycho_test30.hlsli"


// The native matrix + LUT are authored for a bounded gamma-domain signal. Compress
// reversibly, grade in that domain, expand back. Same bridge as Troy.
float3 ApplyPharaohNativeGradeHDRSafe(float3 grade_source_linear)
{
  float grade_scale =
      renodx::tonemap::neutwo::ComputeMaxChannelScale(grade_source_linear, 1.f, HDR_PEAK);
  float3 grade_proxy_linear = grade_source_linear * grade_scale;

  // Stock's saturate(g_brightness * c) is dropped: the proxy is already bounded, and
  // re-clamping would only reintroduce clipping ahead of the matrix and LUT.
  float3 grade_proxy_gamma = renodx::color::gamma::EncodeSafe(grade_proxy_linear);

  float4 matrix_input = float4(grade_proxy_gamma, 1.f);
  float3 matrix_output_gamma;
  matrix_output_gamma.x = dot(matrix_input, colour_matrix._m00_m10_m20_m30);
  matrix_output_gamma.y = dot(matrix_input, colour_matrix._m01_m11_m21_m31);
  matrix_output_gamma.z = dot(matrix_input, colour_matrix._m02_m12_m22_m32);

  // No saturate on the LUT coordinate - stock samples the raw matrix output.
  float3 lut_output_gamma =
      lut_texture.SampleLevel(lut_sampler_s, matrix_output_gamma, 0).xyz;
  float3 graded_gamma = lerp(matrix_output_gamma, lut_output_gamma, lut_strength);

  float3 graded_proxy_linear = renodx::color::gamma::DecodeSafe(graded_gamma);
  return renodx::math::DivideSafe(graded_proxy_linear, grade_scale.xxx, graded_proxy_linear);
}


// Mode 1 user grading. Identity at default settings.
float3 ApplyPharaohHDR1UserGrading(float3 color)
{
  const float3 kLuminance = float3(0.212599993f, 0.715200007f, 0.0722000003f);
  const float mid_gray = 0.18f;

  float luminance = max(dot(color, kLuminance), 0.f);
  float graded_luminance = luminance * SI.exposure_tpm;
  graded_luminance = renodx::color::grade::Highlights(graded_luminance, SI.highlights_tpm, mid_gray);
  graded_luminance = renodx::color::grade::Shadows(graded_luminance, SI.shadows_tpm, mid_gray);

  if (SI.contrast_tpm != 1.f)
  {
    float normalized = max(graded_luminance / mid_gray, 0.f);
    graded_luminance = pow(normalized, SI.contrast_tpm) * mid_gray;
  }

  float tonal_scale = luminance > 0.000001f ? graded_luminance / luminance : 1.f;
  color *= tonal_scale;

  // Luma-preserving saturation. 1.0 is identity.
  float graded_y = dot(color, kLuminance);
  return lerp(graded_y.xxx, color, SI.saturation_tpm);
}


// Mode 1 peak management: rolls everything above 1.0 into the display's headroom.
// Runs last, and leaves everything at or below 1.0 alone - that is the SDR image.
float3 ApplyPharaohHDR1PeakShoulder(float3 color)
{
  float peak = max(HDR_PEAK, 1.0001f);
  float max_channel = max(color.r, max(color.g, color.b));

  if (max_channel > 1.f)
  {
    float headroom = peak - 1.f;
    float excess = max_channel - 1.f;
    float mapped_max = 1.f + renodx::tonemap::Neutwo(excess, headroom);
    color *= mapped_max / max_channel;
  }

  return color;
}


void main(
  float4 v0 : SV_Position0,
  float2 v1 : TEXCOORD0,
  out float4 o0 : SV_Target0)
{
  float4 r0,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10;
  uint4 bitmask, uiDest;
  float4 fDest;

  // Threshold the float setting so a stray value cannot produce a hybrid mode.
  int hdr_mode = (HDR < 0.5f) ? 0 : ((HDR < 1.5f) ? 1 : 2);
  const bool is_hdr = (hdr_mode != 0);

  // Native strength kept; the user multiplier only applies in HDR.
  const float god_rays_multiplier   = is_hdr ? SI.godrays : 1.f;
  const float glow_multiplier       = is_hdr ? SI.bloom : 1.f;
  const float film_grain_multiplier = is_hdr ? SI.filmgrain : 1.f;

  // Stock crossfades the graded result back toward the raw frame. Saturated because it
  // mixes two domains; extrapolating is meaningless and the float target has no clamp.
  const float bypass_mix = saturate(post_processing_strength);

  r0.xy = g_vpos_texel_offset + v0.xy;
  r0.xy = g_screen_size.zw * r0.xy;
  r0.xy = overscan * r0.xy;
  r0.z = cmp(post_processing_strength >= 1);

  // Post-processing bypassed.
  if (r0.z != 0) {
    r1.xyzw = frame_texture.SampleLevel(frame_sampler_s, r0.xy, 0).xyzw;

    if (!is_hdr) {
      r1.xyz = saturate(g_brightness * r1.xyz);
      r1.xyz = log2(r1.xyz);
      r1.xyz = g_inv_gamma_output * r1.xyz;
      o0.xyz = exp2(r1.xyz);
      o0.w = r1.w;

      o0.xyzw = saturate(o0.xyzw);
      o0.xyz = renodx::color::gamma::DecodeSafe(o0.xyz, g_gamma_output);
      o0.xyz *= (SI.diffuse_white_nits / SI.graphics_white_nits);
      o0.xyz = renodx::color::gamma::EncodeSafe(o0.xyz);
      return;
    }

    // Nothing to bridge here, so the tone mapper runs on the raw handoff.
    float3 no_post_hdr = max(r1.xyz, 0.f.xxx);
    if (hdr_mode == 1)
    {
      no_post_hdr = ApplyPharaohHDR1UserGrading(no_post_hdr);
      no_post_hdr = ApplyPharaohHDR1PeakShoulder(no_post_hdr);
    }
    else
    {
      no_post_hdr = ApplyPsychoV30(no_post_hdr);
    }

    o0.xyz = no_post_hdr;
    o0.xyz *= (SI.diffuse_white_nits / SI.graphics_white_nits);
    o0.xyz = renodx::color::gamma::EncodeSafe(o0.xyz);
    o0.w = r1.w;
    return;
  }

  // Full post-processing chain, stock throughout.
  if (r0.z == 0) {
    r1.xyzw = frame_texture.SampleLevel(frame_sampler_s, r0.xy, 0).xyzw;

    // Stock god-ray / glow mask, correct in every mode: t00 hands over mid-grey at 0.18
    // either way, so the mask sees the same numbers it always did.
    r0.z = dot(r1.xyz, float3(0.330000013,0.560000002,0.109999999));
    r0.z = saturate(1 + -r0.z);

    // ### CORRECTED ### asm 44: lt r2.xyz, l(0,0,0,0), cb5[7].yzwy
    // cb5[7] = (overscan, god_rays_strength, glow_strength.x, glow_strength.y), so this
    // gates god rays and glow SEPARATELY. 3Dmigoto named all three after the first
    // field, which would have made god rays off also kill glow.
    r2.x = cmp(0 < god_rays_strength);
    r2.y = cmp(0 < glow_strength.x);
    r2.z = cmp(0 < glow_strength.y);

    if (r2.x != 0) {
      r2.xw = g_render_target_dimensions.xy * r0.xy;
      r2.xw = g_viewport_dimensions.zw * r2.xw;
      r0.w = god_rays_texture.SampleLevel(god_rays_sampler_s, r2.xw, 0).x;
      r3.xyz = sun_colour_unscaled.xyz * r0.www;
      r3.xyz = (god_rays_strength * god_rays_multiplier) * r3.xyz;
      r3.xyz = r3.xyz * r0.zzz + r1.xyz;
    } else {
      r3.xyz = r1.xyz;
    }

    // MSAA vs non-MSAA gbuffer, chosen at runtime.
    r0.w = cmp(1 < g_num_of_samples);
    if (r0.w != 0) {
      gbuffer_channel_4_texture_ms.GetDimensions(uiDest.x, uiDest.y, uiDest.z);
      r2.xw = uiDest.xy;
    } else {
      gbuffer_channel_4_texture.GetDimensions(0, uiDest.x, uiDest.y, uiDest.z);
      r2.xw = uiDest.xy;
    }
    r4.xy = (uint2)r2.xw;
    r4.xy = r4.xy * r0.xy;
    r4.xy = floor(r4.xy);
    r4.xy = (int2)r4.xy;
    r2.xw = (int2)r2.xw + int2(-1,-1);
    r4.xy = max(int2(0,0), (int2)r4.xy);
    r4.xy = min((int2)r4.xy, (int2)r2.xw);
    if (r0.w != 0) {
      r4.z = 0;
      r5.z = gbuffer_channel_4_texture_ms.Load(r4.xy, 0).x;
    } else {
      r4.w = 0;
      r5.z = gbuffer_channel_4_texture.Load(r4.xyw).x;
    }
    r2.xw = g_render_target_dimensions.xy * r0.xy;
    r2.xw = g_viewport_dimensions.zw * r2.xw;
    r5.xy = r2.xw * float2(2,-2) + float2(-1,1);
    r5.w = 1;
    r4.x = dot(r5.xyzw, inv_view_projection._m00_m10_m20_m30);
    r4.y = dot(r5.xyzw, inv_view_projection._m01_m11_m21_m31);
    r4.z = dot(r5.xyzw, inv_view_projection._m02_m12_m22_m32);
    r0.w = dot(r5.xyzw, inv_view_projection._m03_m13_m23_m33);
    r4.xyz = r4.xyz / r0.www;
    r5.xyw = -camera_position.xyz + r4.xyz;
    r0.w = dot(r5.xyw, r5.xyw);
    r6.z = sqrt(r0.w);

    // Glow, gated on either glow_strength component.
    r2.x = (int)r2.z | (int)r2.y;
    if (r2.x != 0) {
      r2.xyz = glow_texture1.SampleLevel(glow_sampler_s, r0.xy, 0).xyz;
      r0.z = r0.z * r0.z;
      r2.xyz = r2.xyz * r0.zzz * glow_multiplier;
      r0.z = cmp(0 != glow_depth_masking);
      if (r0.z != 0) {
        // Height fog + atmosphere transmittance. All of it is exp2 of a negative
        // density producing a [0,1] multiplier, so it is scale-invariant and stays
        // stock. The guards below replace the clamping the UNORM target used to do.
        r0.z = r5.y / max(r6.z, 0.000001f);
        r2.w = g_fog_noise * -0.600000024 + 1;
        r3.w = g_fog_height_bottom + -g_fog_height_top;
        r3.w = g_height_fog_falloff * r3.w + g_fog_height_top;
        r4.w = g_atmosphere_bottom + -camera_position.y;

        // A horizontal ray never reaches the plane, and 0/0 would be NaN. Pushing the
        // denominator off zero makes the max/min below pick the full segment instead.
        r4.w = r4.w / ((abs(r0.z) > 0.000001f) ? r0.z : 0.000001f);

        r4.w = max(0, r4.w);
        r7.z = min(r4.w, r6.z);
        r4.w = cmp(9.99999997e-007 < r0.z);
        r7.x = max(g_atmosphere_bottom, camera_position.y);
        r8.x = cmp(r0.z < -9.99999997e-007);
        r9.y = max(g_atmosphere_bottom, r4.y);
        r9.z = -r7.z + r6.z;
        r9.x = camera_position.y;
        r9.w = g_atmosphere_bottom;
        r6.xy = float2(0,0);
        r6.w = camera_position.y;
        r8.xyzw = r8.xxxx ? r9.xyzw : r6.xyzw;
        r7.y = r4.y;
        r7.w = g_atmosphere_bottom;
        r7.xyzw = r4.wwww ? r7.xyzw : r8.xyzw;
        r8.xyzw = -g_atmosphere_bottom + r7.wwxy;
        r8.xyzw = max(float4(0,0,0,0), r8.xyzw);
        r9.xyzw = float4(6994,1200,6994,6994) * g_atmosphere_height_multiplier;
        r10.xyzw = -r8.xyzw / r9.xyzw;
        r10.xyzw = float4(1.44269502,1.44269502,1.44269502,1.44269502) * r10.xyzw;
        r10.xyzw = exp2(r10.xyzw);
        r4.yw = r10.xy * r7.zz;
        r6.xy = cmp(float2(9.99999997e-007,9.99999972e-010) < abs(r0.zz));
        r6.w = r10.z + -r10.w;
        r6.w = r6.w * r9.w;
        r6.w = r6.w / r0.z;
        r7.x = r10.x * r7.z + r6.w;
        r8.xy = -r8.zw / r9.yy;
        r8.xy = float2(1.44269502,1.44269502) * r8.xy;
        r8.xy = exp2(r8.xy);
        r6.w = r8.x + -r8.y;
        r6.w = r6.w * r9.y;
        r6.w = r6.w / r0.z;
        r7.y = r10.y * r7.z + r6.w;
        r4.yw = r6.xx ? r7.xy : r4.yw;
        r6.w = cmp(camera_position.y >= g_fog_height_bottom);
        r7.x = cmp(r3.w >= camera_position.y);
        r6.w = r6.w ? r7.x : 0;
        r7.x = -camera_position.y + r3.w;
        r7.x = r7.x / r0.z;
        r7.x = max(0, r7.x);
        r7.x = min(r7.x, r6.z);
        r6.w = r6.w ? r6.z : 0;
        r6.w = r6.x ? r7.x : r6.w;

        // ### CORRECTED ### asm 144: add r7.yz, -cb1[0].yyyy, cb3[0].zzwz
        // .zzwz reads bottom into y and TOP into z. 3Dmigoto used bottom for both,
        // which collapses the height-fog slab to zero thickness.
        r7.y = g_fog_height_bottom + -camera_position.y;
        r7.z = g_fog_height_top + -camera_position.y;

        r7.yz = r7.yz / r0.zz;
        r7.yz = max(float2(0,0), r7.yz);
        r7.yz = min(r7.yz, r6.zz);
        r7.y = r6.x ? r7.y : 0;
        r6.w = -r7.y + r6.w;
        r2.w = g_fog_density_height * r2.w;
        r2.w = 0.0125000002 * r2.w;
        r7.y = cmp(camera_position.y >= r3.w);
        r7.w = cmp(g_fog_height_top >= camera_position.y);
        r7.y = r7.w ? r7.y : 0;
        r7.w = r7.y ? r6.z : 0;
        r7.z = r6.x ? r7.z : r7.w;
        r6.x = r6.x ? r7.x : 0;
        r7.x = max(r6.x, r7.z);
        r6.x = min(r6.x, r7.z);
        r7.z = r6.x * r0.z + camera_position.y;
        r6.x = r7.x + -r6.x;
        r3.w = g_fog_height_top + -r3.w;
        r7.x = cmp(0 != r3.w);
        r3.w = 1 / r3.w;
        r3.w = r7.x ? r3.w : 0;
        r7.x = g_fog_height_top + -r7.z;
        r0.z = r6.x * r0.z;
        r0.z = -r0.z * 0.5 + r7.x;
        r0.z = r0.z * r6.x;
        r0.z = r0.z * r3.w;
        r3.w = (int)r6.y | (int)r7.y;
        r0.z = r2.w * r0.z;
        r0.z = (int)r0.z & (int)r3.w;
        r0.z = r2.w * abs(r6.w) + r0.z;
        r2.w = 2.20000002e-005 * r4.w;
        r6.xyw = g_rayleigh_density.xyz * r4.yyy + r2.www;
        r6.xyw = g_fog_density_constant * r6.xyw + r0.zzz;
        r0.z = max(r6.x, r6.y);
        r0.z = max(r0.z, r6.w);
        r0.z = -1.44269502 * r0.z;
        r0.z = exp2(r0.z);
        r2.w = cmp(0 != g_campaign_map_size.x);
        if (r2.w != 0) {
          r0.x = t_shroud_clouds.SampleLevel(s_shroud_clouds_s, r0.xy, 0).w;
          r0.z = r0.z * r0.x;
        }
        r0.x = cmp(r5.z == 1.000000);
        r0.x = r0.x ? 1.000000 : 0;
        r0.y = glow_strength.y + -glow_strength.x;
        r0.y = r0.x * r0.y + glow_strength.x;
        r0.x = -r0.x * r0.z + 1;
        r0.x = r0.x * r0.y;
        r2.xyz = r2.xyz * r0.xxx;
      }
      r3.xyz = r3.xyz + r2.xyz;
    }

    // Rain. Scale-agnostic streaks, untouched apart from the rsqrt guards.
    r0.x = cmp(0 < g_rain_color.w);
    if (r0.x != 0) {
      r0.x = rsqrt(max(r0.w, 1e-12f));
      r0.xyz = r5.xyw * r0.xxx;
      r2.x = dot(r0.xyz, g_rain_camera_mat_col1.xyz);
      r2.y = dot(r0.xyz, g_rain_camera_mat_col2.xyz);
      r2.z = dot(r0.xyz, g_rain_camera_mat_col3.xyz);
      r0.x = dot(r2.xyz, r2.xyz);
      r0.x = rsqrt(max(r0.x, 1e-12f));
      r0.yzw = r2.xyz * r0.xxx;
      r2.xz = abs(r0.yw) * abs(r0.yw);
      r4.yw = cmp(float2(0,0) < r0.yw);
      r2.w = 3.5 * g_rain_direction.w;
      r0.x = saturate(-r2.y * r0.x + 0.899999976);
      r2.xy = -r2.xz * abs(r0.yw) + float2(1,1);
      r5.yzw = g_rain_camera_position.yxz;
      r2.z = 0;
      r3.w = 0;
      r6.x = 0;
      while (true) {
        r6.y = cmp((int)r6.x >= rain_planes_count);
        if (r6.y != 0) break;
        r6.yw = frac(r5.zw);
        r7.xy = float2(1,1) + -r6.yw;
        r6.yw = r4.yw ? r7.xy : r6.yw;
        r7.xy = r6.yw * abs(r0.wy);
        r7.x = cmp(r7.y < r7.x);
        if (r7.x != 0) {
          r7.x = r6.w / abs(r0.w);
          r3.w = r7.x + r3.w;
          r7.xyz = r6.www * r0.yzy;
          r7.xyz = r7.xyz / abs(r0.www);
          r6.w = 0.00999999978 + r6.w;
          r6.w = r6.w * r0.w;
          r7.w = r6.w / abs(r0.w);
          r5.xyzw = r5.zyzw;
          r5.xyzw = r5.xyzw + r7.xyzw;
          r7.xyz = float3(1.29999995,4.5999999,4.5999999) * r5.xzw;
          r6.w = r5.y * 0.899999976 + r2.w;
          r7.w = floor(r5.w);
          r7.w = 34 * r7.w;
          r7.w = sin(r7.w);
          r6.w = r7.w * 0.324000001 + r6.w;
          r8.x = frac(r7.x);
          r8.y = frac(r6.w);
          r6.w = rain_texture.Sample(rain_sampler_s, r8.xy).x;
          r7.xy = sin(r7.yz);
          r7.x = r7.x * r7.y;
          r7.y = g_rain_direction.w * 4.19999981 + r5.y;
          r7.y = 1.29999995 * r7.y;
          r7.y = sin(r7.y);
          r7.x = r7.x * r7.y;
          r7.x = max(0, r7.x);
          r7.x = r7.x * 0.800000012 + 0.200000003;
          r6.w = r7.x * r6.w;
          r7.x = 1.29999995 * r3.w;
          r7.x = min(1, r7.x);
          r7.y = saturate(r6.z * g_rain_camera_position.w + -r3.w);
          r7.x = r7.x * r7.y;
          r7.x = r7.x * r0.x;
          r7.x = r7.x * r2.x;
          r2.z = r6.w * r7.x + r2.z;
        } else {
          r6.w = r6.y / abs(r0.y);
          r3.w = r6.w + r3.w;
          r6.w = 0.00999999978 + r6.y;
          r6.w = r6.w * r0.y;
          r7.z = r6.w / abs(r0.y);
          r8.xyz = r6.yyy * r0.wzw;
          r7.xyw = r8.xyz / abs(r0.yyy);
          r5.xyzw = r5.wyzw;
          r5.xyzw = r5.xyzw + r7.xyzw;
          r7.xyz = float3(1.29999995,4.5999999,4.5999999) * r5.xzw;
          r5.x = r5.y * 0.899999976 + r2.w;
          r6.y = floor(r5.z);
          r6.y = 34 * r6.y;
          r6.y = sin(r6.y);
          r5.x = r6.y * 0.324000001 + r5.x;
          r8.x = frac(r7.x);
          r8.y = frac(r5.x);
          r5.x = rain_texture.Sample(rain_sampler_s, r8.xy).x;
          r6.yw = sin(r7.yz);
          r6.y = r6.y * r6.w;
          r6.w = g_rain_direction.w * 4.19999981 + r5.y;
          r6.w = 1.29999995 * r6.w;
          r6.w = sin(r6.w);
          r6.y = r6.y * r6.w;
          r6.y = max(0, r6.y);
          r6.y = r6.y * 0.800000012 + 0.200000003;
          r5.x = r6.y * r5.x;
          r6.y = 1.29999995 * r3.w;
          r6.y = min(1, r6.y);
          r6.w = saturate(r6.z * g_rain_camera_position.w + -r3.w);
          r6.y = r6.y * r6.w;
          r6.y = r6.y * r0.x;
          r6.y = r6.y * r2.y;
          r2.z = r5.x * r6.y + r2.z;
        }
        r6.x = (int)r6.x + 1;
      }
      r0.x = 1 + g_rain_lightning.w;
      r0.x = r2.z * r0.x;
      r0.xyz = g_rain_color.xyz * r0.xxx;
      r3.xyz = r0.xyz * g_rain_color.www + r3.xyz;
    }

    // Fog of war. lerp(0.25*luminance, colour, blend) - multiplicative, so scale-safe.
    r0.xw = r4.xz * float2(0.00048828125,0.00048828125) + float2(0.5,0.5);
    r2.x = 1 + -r0.w;
    r2.y = cmp(r0.x < 0);
    r2.z = cmp(1 < r0.x);
    r2.y = (int)r2.z | (int)r2.y;
    r2.z = cmp(r2.x < 0);
    r2.y = (int)r2.z | (int)r2.y;
    r2.x = cmp(1 < r2.x);
    r2.x = (int)r2.x | (int)r2.y;
    if (r2.x == 0) {
      r0.yz = float2(1,1) + -r0.xw;
      r2.x = t_fog_of_war_mask.SampleLevel(s_fog_of_war_mask_s, r0.xz, 0).x;
      r2.y = cmp(g_fog_of_war_outfield_blend < 1);
      r0.xyzw = float4(50,50,50,50) * r0.xyzw;
      r0.xyzw = min(float4(1,1,1,1), r0.xyzw);
      r0.xy = min(r0.xz, r0.yw);
      r0.x = min(r0.x, r0.y);
      r0.x = 1 + -r0.x;
      r0.x = max(r2.x, r0.x);
      r0.x = r2.y ? r0.x : r2.x;
      r0.y = 1 + -g_fog_of_war_blend;
      r0.x = max(r0.x, r0.y);
    } else {
      r0.x = -g_fog_of_war_outfield_blend * g_fog_of_war_blend + 1;
    }
    r0.y = dot(r3.xyz, float3(0.270000011,0.670000017,0.0599999987));
    r2.xyz = float3(0.25,0.25,0.25) * r0.yyy;
    r2.w = r1.w;
    r3.xyz = -r0.yyy * float3(0.25,0.25,0.25) + r3.xyz;
    r3.w = 0;
    r0.xyzw = r0.xxxx * r3.xyzw + r2.xyzw;

    // Film grain. Multiplicative, so scale-invariant.
    r1.w = cmp(0 < grain_tex_offset_enabled.z);
    if (r1.w != 0) {
      r2.xy = v0.xy / g_screen_size.yy;
      r2.xy = grain_tex_offset_enabled.xy + r2.xy;
      r2.xy = float2(6,6) * r2.xy;
      r1.w = grain_texture.SampleLevel(grain_sampler_s, r2.xy, 0).x;
      r1.w = r1.w * 2 + -1;
      r2.xyz = r1.www * r0.xyz;
      r0.xyz = r2.xyz * (grain_tex_offset_enabled.zzz * film_grain_multiplier) + r0.xyz;
    }

    // Final grade + output.
    if (!is_hdr)
    {
      r2.xyz = saturate(g_brightness * r0.xyz);
      r2.xyz = log2(r2.xyz);
      r2.xyz = g_inv_gamma_output * r2.xyz;
      r2.xyz = exp2(r2.xyz);
      r2.w = 1;
      r3.x = dot(r2.xyzw, colour_matrix._m00_m10_m20_m30);
      r3.y = dot(r2.xyzw, colour_matrix._m01_m11_m21_m31);
      r3.z = dot(r2.xyzw, colour_matrix._m02_m12_m22_m32);
      r2.xyz = lut_texture.SampleLevel(lut_sampler_s, r3.xyz, 0).xyz;
      r2.xyz = r2.xyz + -r3.xyz;
      r0.xyz = lut_strength * r2.xyz + r3.xyz;
      r1.w = cmp(0 < post_processing_strength);
      if (r1.w != 0) {
        r1.xyz = saturate(g_brightness * r1.xyz);
        r1.xyz = log2(r1.xyz);
        r1.xyz = g_inv_gamma_output * r1.xyz;
        r1.xyz = exp2(r1.xyz);
        r1.xyz = r1.xyz + -r0.xyz;
        r0.xyz = post_processing_strength * r1.xyz + r0.xyz;
      }
      o0.xyzw = r0.xyzw;

      // Restore the UNORM write clamp on the upgraded target.
      o0.xyzw = saturate(o0.xyzw);

      o0.xyz = renodx::color::gamma::DecodeSafe(o0.xyz, g_gamma_output);
      o0.xyz *= (SI.diffuse_white_nits / SI.graphics_white_nits);
      o0.xyz = renodx::color::gamma::EncodeSafe(o0.xyz);
      return;
    }

    // HDR: native matrix + LUT in their own domain, then the mode's tone mapper.
    float output_alpha = r0.w;
    float3 graded_hdr = ApplyPharaohNativeGradeHDRSafe(max(r0.xyz, 0.f.xxx));

    // Stock's crossfade toward the raw frame, done in linear rather than gamma so both
    // sides are on the same scale.
    if (bypass_mix > 0.f)
    {
      graded_hdr = lerp(graded_hdr, max(r1.xyz, 0.f.xxx), bypass_mix);
    }

    if (hdr_mode == 1)
    {
      // Faithful. At defaults this leaves the SDR image intact.
      graded_hdr = ApplyPharaohHDR1UserGrading(graded_hdr);
      graded_hdr = ApplyPharaohHDR1PeakShoulder(graded_hdr);
    }
    else
    {
      graded_hdr = ApplyPsychoV30(graded_hdr);
    }

    o0.xyz = graded_hdr;
    o0.xyz *= (SI.diffuse_white_nits / SI.graphics_white_nits);
    o0.xyz = renodx::color::gamma::EncodeSafe(o0.xyz);
    o0.w = output_alpha;
  }
  return;
}
