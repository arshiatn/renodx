// AA off

// ---- Created with 3Dmigoto v1.3.16 on Sat Sep 19 22:44:32 2026
//
// TROY - ui01 - UI PANEL SCENE BACKDROP (advisor panel and friends)
//
// Samples g_hdr_rgb_texture - the raw scene HDR buffer, BEFORE t00 tone maps it -
// gamma-encodes it with sqrt() (a gamma 2.0 encode), multiplies by the stencil and
// by 0.5. The live scene showing through a UI panel, masked by t_alt_map and the
// stencil. Because it reads the pre-tonemap buffer it behaves identically in HDR 1
// and HDR 2 - the rendering mode never touches it.
//
// Draw order 618, well after t01 (466), so this blends into the finished frame.
//
// ===========================================================================
// WHY A ROLLOFF IS POSSIBLE HERE
// ===========================================================================
// Everything past o0 = 1.0 used to be thrown away by the R8G8B8A8_UNORM target:
//
//   o0 = 0.5 * sqrt(scene)   ->   o0 reaches 1.0 at scene = 4.0
//
// Mid grey in that buffer is about 0.87, so scene 4.0 is only ~2.2 stops above it -
// a bright sky or a sunlit wall clears it easily and used to land as flat white.
// The detail was never destroyed by the shader, only by the write, so a shoulder
// can genuinely show it instead of inventing it. That is the difference between
// this pass and, say, the lens flares.
//
// TWO THINGS THAT HAVE TO BE RIGHT:
//
// 1. DOMAIN. Stock encodes with sqrt() (gamma 2.0), but the swapchain decodes 2.2 -
//    and so did the display in stock. So decode 2.2, shoulder in linear light,
//    encode 2.2: an exact identity below the knee. 1.0 here is UI white.
//
// 2. CEILING. The recovered backdrop is allowed to use the actual HDR display peak.
//    Because 1.0 in this compositing buffer corresponds to UI white, the shoulder
//    ceiling is peak_white_nits / graphics_white_nits. This preserves the stock
//    0.5 backdrop attenuation while no longer imposing an arbitrary Paper White + 1
//    stop cap.
//
// SDR keeps the hard clamp, which is exactly the stock UNORM behaviour.

cbuffer camera : register(b0)
{
  float3 camera_position : packoffset(c0);
  float4x4 view : packoffset(c1);
  float4x4 projection : packoffset(c5);
  float4x4 view_projection : packoffset(c9);
  float4x4 inv_view : packoffset(c13);
  float4x4 inv_projection : packoffset(c17);
  float4x4 inv_view_projection : packoffset(c21);
  float4 camera_near_far : packoffset(c25);
  float time_in_sec : packoffset(c26);
  float2 g_inverse_focal_length : packoffset(c26.y);
  float g_vertical_fov : packoffset(c26.w);
  float4 g_screen_size : packoffset(c27);
  float g_vpos_texel_offset : packoffset(c28);
  float4 g_viewport_dimensions : packoffset(c29);
  float2 g_viewport_origin : packoffset(c30);
  float4 g_render_target_dimensions : packoffset(c31);
  float4 g_camera_temp0 : packoffset(c32);
  float4 g_camera_temp1 : packoffset(c33);
  float4 g_camera_temp2 : packoffset(c34);
  float4 g_clip_rect : packoffset(c35);
  float3 g_vr_head_rotation : packoffset(c36);
  int g_num_of_samples : packoffset(c36.w);
  float g_supersampling : packoffset(c37);
  float4 g_mouse_position : packoffset(c38);
  float3 g_frustum_points[8] : packoffset(c39);
  float g_orthographic : packoffset(c46.w);
  float g_overlay_lerp : packoffset(c47);
  float g_overlay_parchment_lerp : packoffset(c47.y);
  float g_overlay_palette_alpha : packoffset(c47.z);
  float g_debug_tonemapping : packoffset(c47.w);
  float4 g_blood_remap : packoffset(c48);
}

cbuffer sprite_PS : register(b1)
{
  float g_windows_time_PS : packoffset(c0);
  float g_model_time_PS : packoffset(c0.y);
  float g_text_rendering_enabled_PS : packoffset(c0.z);
  float2 g_screen_dimensions_PS : packoffset(c1);
  float2 g_campaign_shroud_uv_offset : packoffset(c1.z);
  float4 g_texture_dimensions : packoffset(c2);
  float4 g_mask_and_image_dimensions : packoffset(c3);
  float4 g_mask_position_and_pivot_position : packoffset(c4);
  float4x4 g_mask_transform : packoffset(c5);
  float2 g_mask_atlas_uvs : packoffset(c9);
  float2 g_texture_atlas_size : packoffset(c9.z);
}

cbuffer constant_tone_mapping_buffer : register(b2)
{
  float g_luma_black_point : packoffset(c0);
  float g_luma_white_point : packoffset(c0.y);
  float4 g_tc_remap : packoffset(c1);
}

SamplerState s_alt_map_s : register(s0);
SamplerState g_hdr_rgb_texture_sampler_s : register(s1);
Texture2D<float4> t_alt_map : register(t0);
Texture2D<float4> g_hdr_rgb_texture : register(t1);
Texture2D<float> g_stencil_texture : register(t2);


// 3Dmigoto declarations
#define cmp -
#include "../shared.h"


void main(
  float4 v0 : SV_Position0,
  float2 v1 : TEXCOORD0,
  out float4 o0 : SV_Target0)
{
  float4 r0,r1,r2;
  uint4 bitmask, uiDest;
  float4 fDest;

  r0.xy = v0.xy * g_tc_remap.xy + g_tc_remap.zw;
  r0.xy = g_vpos_texel_offset + r0.xy;
  r0.xy = g_screen_size.zw * r0.xy;
  r0.z = g_stencil_texture.SampleLevel(g_hdr_rgb_texture_sampler_s, r0.xy, 0).x;
  r0.w = cmp(0 < g_mask_and_image_dimensions.z);
  if (r0.w != 0) {
    r1.xy = -g_mask_position_and_pivot_position.zw + v0.xy;
    r1.zw = v0.zw;
    r2.x = dot(r1.xyzw, g_mask_transform._m00_m10_m20_m30);
    r2.y = dot(r1.xyzw, g_mask_transform._m01_m11_m21_m31);
    r1.xy = g_mask_position_and_pivot_position.zw + r2.xy;
    r1.xy = -g_mask_position_and_pivot_position.xy + r1.xy;
    r1.xy = r1.xy / g_mask_and_image_dimensions.xy;
    r1.zw = g_mask_and_image_dimensions.zw / g_texture_atlas_size.xy;
    r1.zw = r1.xy * r1.zw + g_mask_atlas_uvs.xy;
    r2.xy = cmp(r1.xy >= float2(0,0));
    r1.xy = cmp(float2(1,1) >= r1.xy);
    r0.w = r1.x ? r2.x : 0;
    r0.w = r2.y ? r0.w : 0;
    r0.w = r1.y ? r0.w : 0;
    if (r0.w != 0) {
      r0.w = t_alt_map.SampleLevel(s_alt_map_s, r1.zw, 0).w;
    } else {
      r0.w = 0;
    }
    r0.w = -0.5 + r0.w;
    r0.w = cmp(r0.w < 0);
    if (r0.w != 0) discard;
  }

  r0.xyw = g_hdr_rgb_texture.SampleLevel(g_hdr_rgb_texture_sampler_s, r0.xy, 0).xyz;

  // The scene buffer can carry small negatives from some passes, and sqrt() of a
  // negative is NaN. The stock UNORM target flushed that to 0 in the ROP; an FP16
  // target propagates it straight into the panel.
  r0.xyw = sqrt(max(r0.xyw, 0.f.xxx));

  r0.xyw = r0.xyw * r0.zzz;
  o0.xyz = float3(0.5,0.5,0.5) * r0.xyw;
  o0.w = r0.z;

  if (HDR >= 0.5f)
  {
    // Stock's sqrt() is gamma 2.0, but the swapchain decodes 2.2 (as the display
    // did in stock). Decoding 2.2 keeps the round trip exact below the knee.
    float3 backdrop =
        renodx::color::gamma::DecodeSafe(
            max(o0.xyz, 0.f.xxx));

    // Let the recovered backdrop use the actual display peak.
    // 1.0 in this compositing buffer corresponds to UI white.
    float ui_white = max(SI.graphics_white_nits, 0.0001f);
    float ceiling =
        max(SI.peak_white_nits / ui_white, 1.0001f);

    // Max-channel shoulder so hue is preserved, and an exact identity at or below
    // 1.0 - everything the panel already showed correctly is left untouched.
    float max_channel = max(backdrop.r, max(backdrop.g, backdrop.b));
    if (max_channel > 1.f)
    {
      float mapped = 1.f + renodx::tonemap::Neutwo(max_channel - 1.f, ceiling - 1.f);
      backdrop *= mapped / max_channel;
    }

    o0.xyz = renodx::color::gamma::EncodeSafe(backdrop);
    return;
  }

  // SDR: the stock UNORM write clamp, restored explicitly.
  o0.xyz = saturate(o0.xyz);
  return;
}
