// ONLY WITH CHROMATIC ABERRATION
//
// TROY - chromatic aberration (CA on, sharpening off)
//
// ===========================================================================
// THE BLACK SCREEN IS NOT IN THIS SHADER - IT IS DRAW 1388
// ===========================================================================
// From your own trace:
//
//   1387  lensflare04   RTV0 = r16g16b16a16_float  3840x2160
//   1388  Copy          Source      = r16g16b16a16_float  3840x2160
//                       Destination = r8g8b8a8_unorm      3840x2160
//   1389  chromatic00   T0   = r8g8b8a8_unorm      3840x2160
//                       RTV0 = r16g16b16a16_float
//
// The game CopyResource's the finished frame into a separate staging texture and
// reads THAT as t_frame. Your upgrade turned the source into FP16 but left the
// destination at R8G8B8A8_UNORM, and a D3D11 CopyResource requires matching format
// families - 64 bits per pixel into 32 does not copy. The call fails, the staging
// texture keeps whatever it had (nothing), and t_frame reads as black.
//
// WHY UpgradeRTVReplaceShader DID NOT HELP:
//   That macro hot-swaps RENDER TARGET VIEWS. This texture is never a render target
//   - it is a copy destination read through an SRV. Your resource_upgrade_infos rule
//   filters on
//       .usage_include = reshade::api::resource_usage::render_target
//   so this resource is skipped entirely. It needs its own rule; see the notes file.
//
// Once the destination is FP16 the copy succeeds and this pass gets the real frame.
//
// ===========================================================================
// WHAT THIS SHADER NEEDED
// ===========================================================================
// Almost nothing. It has no saturate and no clamp - it only reorders channels and
// re-samples red and blue at opposite radial offsets, so HDR values pass through
// untouched once the input is no longer black. The single fix is the log2(0) at the
// exact screen centre, same as the vignette pass:
//
//   d2 = dot(offset, offset);  log2(d2);
//
// where offset is (uv - 0.5) * 2. At the centre pixel d2 is 0, log2(0) is -inf, and
// -inf * 0 is NaN if g_chromatic_aberration_falloff is ever 0. Stock's UNORM target
// flushed it; the FP16 target will not.
//
// The channel dance is stock and correct: Load().xzy puts (r, b, g) in r0.xyz, the
// two offset samples overwrite red and blue, and o0 = r0.xzyw reorders back to
// (r, g, b, 1).

cbuffer camera : register(b0)
{
  float3 camera_position : packoffset(c0);
  float4x4 view : packoffset(c1);
  float4x4 projection : packoffset(c5);
  float4x4 view_projection : packoffset(c9);
  float4x4 inv_view : packoffset(c13);
  float4x4 inv_projection : packoffset(c17);
  float4x4 inv_view_projection : packoffset(c21);
  float4 camera_near_far : packoffset(c25);
  float time_in_sec : packoffset(c26);
  float2 g_inverse_focal_length : packoffset(c26.y);
  float g_vertical_fov : packoffset(c26.w);
  float4 g_screen_size : packoffset(c27);
  float g_vpos_texel_offset : packoffset(c28);
  float4 g_viewport_dimensions : packoffset(c29);
  float2 g_viewport_origin : packoffset(c30);
  float4 g_render_target_dimensions : packoffset(c31);
  float4 g_camera_temp0 : packoffset(c32);
  float4 g_camera_temp1 : packoffset(c33);
  float4 g_camera_temp2 : packoffset(c34);
  float4 g_clip_rect : packoffset(c35);
  float3 g_vr_head_rotation : packoffset(c36);
  int g_num_of_samples : packoffset(c36.w);
  float g_supersampling : packoffset(c37);
  float4 g_mouse_position : packoffset(c38);
  float3 g_frustum_points[8] : packoffset(c39);
  float g_orthographic : packoffset(c46.w);
  float g_overlay_lerp : packoffset(c47);
  float g_overlay_parchment_lerp : packoffset(c47.y);
  float g_overlay_palette_alpha : packoffset(c47.z);
  float g_debug_tonemapping : packoffset(c47.w);
  float4 g_blood_remap : packoffset(c48);
}

cbuffer SHARPEN_CONSTANTS : register(b1)
{
  float g_sharpening_strength : packoffset(c0);
  float g_chromatic_aberration_strength : packoffset(c0.y);
  float g_chromatic_aberration_falloff : packoffset(c0.z);
}

SamplerState s_frame_s : register(s0);
Texture2D<float3> t_frame : register(t0);


// 3Dmigoto declarations
#define cmp -
#include "../shared.h"


void main(
  float4 v0 : SV_Position0,
  out float4 o0 : SV_Target0)
{
  float4 r0,r1,r2;
  uint4 bitmask, uiDest;
  float4 fDest;

  r0.xy = (int2)v0.xy;
  r0.zw = float2(0,0);
  r0.xyz = t_frame.Load(r0.xyz).xzy;
  // SI.chromaticaberration scales the game's own strength. At 0 the branch below is
  // skipped entirely, so the slider doubles as an off switch. HDR only - SDR keeps
  // the stock value.
  float ca_strength =
      g_chromatic_aberration_strength * ((HDR >= 0.5f) ? SI.chromaticaberration : 1.f);

  r1.x = cmp(0 < ca_strength);
  if (r1.x != 0) {
    r1.xy = trunc(v0.xy);
    r1.xy = float2(0.5,0.5) + r1.xy;
    r1.zw = r1.xy * g_render_target_dimensions.zw + float2(-0.5,-0.5);
    r1.zw = r1.zw + r1.zw;
    r1.z = dot(r1.zw, r1.zw);

    // Guard: at the exact screen centre this is 0, log2(0) is -inf, and -inf * 0 is
    // NaN when the falloff is 0. Stock's UNORM target flushed it; FP16 does not.
    r1.z = log2(max(r1.z, 1e-12f));
    r1.z = g_chromatic_aberration_falloff * r1.z;
    r1.z = exp2(r1.z);
    r1.z = ca_strength * r1.z;
    r1.z = r1.z * r1.z + 1;
    r1.z = r1.z * r1.z;
    r1.z = 1 / r1.z;
    r1.z = 1 + -r1.z;
    r2.xy = r1.xy * g_render_target_dimensions.zw + -r1.zz;
    r0.x = t_frame.SampleLevel(s_frame_s, r2.xy, 0).x;
    r1.xy = r1.xy * g_render_target_dimensions.zw + r1.zz;
    r0.y = t_frame.SampleLevel(s_frame_s, r1.xy, 0).z;
  }
  r0.w = 1;
  o0.xyzw = r0.xzyw;
  return;
}