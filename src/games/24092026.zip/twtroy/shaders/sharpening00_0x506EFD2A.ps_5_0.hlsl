// Chromatic aberration on/off + sharpening on
//
// TROY - sharpening (+ optional chromatic aberration)
//
// ===========================================================================
// THE BLACK SCREEN IS NOT IN THIS SHADER - IT IS DRAW 1388
// ===========================================================================
// Your trace shows the game CopyResource's the finished frame into a separate
// staging texture and reads THAT as t_frame:
//
//   1387  lensflare04   RTV0 = r16g16b16a16_float  3840x2160
//   1388  Copy          Source      = r16g16b16a16_float  3840x2160
//                       Destination = r8g8b8a8_unorm      3840x2160
//   1389  chromatic00   T0   = r8g8b8a8_unorm      3840x2160
//
// The upgrade made the source FP16 but left the destination R8G8B8A8_UNORM. A D3D11
// CopyResource needs matching format families - 64 bits per pixel into 32 is not a
// legal copy. It fails, the staging texture keeps nothing, t_frame reads black.
//
// UpgradeRTVReplaceShader cannot fix it: that hot-swaps RENDER TARGET VIEWS, and this
// texture is never a render target - it is a copy destination read through an SRV.
// Your resource_upgrade_infos rule filters on
//     .usage_include = reshade::api::resource_usage::render_target
// so the resource is skipped. It needs its own rule; see the notes file.
//
// ===========================================================================
// WHAT THIS SHADER NEEDED: THE saturate() HAD TO GO IN HDR
// ===========================================================================
// Stock ends with
//
//     o0.xyz = saturate(g_sharpening_strength * laplacian + centre);
//
// Harmless on a UNORM target, fatal on the HDR frame: after t01-t08 the buffer is
// gamma-encoded and carries values well past 1.0 (about 3.1 at HDR_PEAK 12.3), so
// this would flatten every highlight to UI white. Sharpening would silently cost you
// the entire HDR range - the exact thing the whole mod exists to keep.
//
// The lower clamp stays: a Laplacian legitimately undershoots below zero on high
// contrast edges, and that ringing should still be clipped. Only the ceiling is
// dropped, and only in HDR, so SDR is byte-for-byte stock.
//
// The kernel itself is scale-free - centre + strength * (4*centre - 4 neighbours) -
// so it needs no other HDR adaptation.
//
// Also guarded: the log2(0) in the CA block, same as chromatic00 and the vignette.

cbuffer camera : register(b0)
{
  float3 camera_position : packoffset(c0);
  float4x4 view : packoffset(c1);
  float4x4 projection : packoffset(c5);
  float4x4 view_projection : packoffset(c9);
  float4x4 inv_view : packoffset(c13);
  float4x4 inv_projection : packoffset(c17);
  float4x4 inv_view_projection : packoffset(c21);
  float4 camera_near_far : packoffset(c25);
  float time_in_sec : packoffset(c26);
  float2 g_inverse_focal_length : packoffset(c26.y);
  float g_vertical_fov : packoffset(c26.w);
  float4 g_screen_size : packoffset(c27);
  float g_vpos_texel_offset : packoffset(c28);
  float4 g_viewport_dimensions : packoffset(c29);
  float2 g_viewport_origin : packoffset(c30);
  float4 g_render_target_dimensions : packoffset(c31);
  float4 g_camera_temp0 : packoffset(c32);
  float4 g_camera_temp1 : packoffset(c33);
  float4 g_camera_temp2 : packoffset(c34);
  float4 g_clip_rect : packoffset(c35);
  float3 g_vr_head_rotation : packoffset(c36);
  int g_num_of_samples : packoffset(c36.w);
  float g_supersampling : packoffset(c37);
  float4 g_mouse_position : packoffset(c38);
  float3 g_frustum_points[8] : packoffset(c39);
  float g_orthographic : packoffset(c46.w);
  float g_overlay_lerp : packoffset(c47);
  float g_overlay_parchment_lerp : packoffset(c47.y);
  float g_overlay_palette_alpha : packoffset(c47.z);
  float g_debug_tonemapping : packoffset(c47.w);
  float4 g_blood_remap : packoffset(c48);
}

cbuffer SHARPEN_CONSTANTS : register(b1)
{
  float g_sharpening_strength : packoffset(c0);
  float g_chromatic_aberration_strength : packoffset(c0.y);
  float g_chromatic_aberration_falloff : packoffset(c0.z);
}

SamplerState s_frame_s : register(s0);
Texture2D<float3> t_frame : register(t0);


// 3Dmigoto declarations
#define cmp -
#include "../shared.h"


// ===========================================================================
// g_sharpening_strength READS AS ZERO
// ===========================================================================
// Confirmed empirically: multiplying it by 1000 changes nothing, which only happens
// if the value is exactly 0. The cbuffer layout itself is trustworthy - 3Dmigoto
// takes it from the shader's own RDEF reflection chunk, not from guesswork - so the
// game really is writing 0 into this field even in the permutation that only exists
// when sharpening is enabled.
//
// DIAGNOSTIC: chromatic aberration lives in the SAME cbuffer, one float along.
//   - CA works, sharpening does not  -> the cbuffer is bound and the game writes a
//     genuine 0 here. The fallback below is the fix.
//   - CA is also dead                -> SHARPEN_CONSTANTS (b1) is not bound at all
//     when this pass runs, both fields read 0, and the fallback is a workaround
//     rather than a fix. Check CB1 on this draw in the devkit trace.
//
// The fallback only engages in HDR. SDR keeps whatever the game supplies, even when
// that is 0, so the SDR image stays exactly stock rather than gaining a sharpen the
// game never asked for.
//
// kSharpenBaseFallback is a judgement call, not a recovered constant - I have no way
// to know what the game intended. 0.15 with the slider at 1.0 is a mild, sane
// Laplacian amount; the 0-2 slider then covers 0 to 0.3. Raise it if the default
// reads too soft.
static const float kSharpenBaseFallback = 0.075f;


void main(
  float4 v0 : SV_Position0,
  out float4 o0 : SV_Target0)
{
  float4 r0,r1,r2,r3,r4;
  uint4 bitmask, uiDest;
  float4 fDest;

  r0.xy = (int2)v0.xy;
  r0.zw = float2(0,0);
  r1.xyz = t_frame.Load(r0.xyz).xzy;
  // SI.chromaticaberration scales the game's own strength. At 0 the branch below is
  // skipped entirely, so the slider doubles as an off switch. HDR only - SDR keeps
  // the stock value.
  float ca_strength =
      g_chromatic_aberration_strength * ((HDR >= 0.5f) ? SI.chromaticaberration : 1.f);

  r0.z = cmp(0 < ca_strength);
  if (r0.z != 0) {
    r0.zw = trunc(v0.xy);
    r0.zw = float2(0.5,0.5) + r0.zw;
    r2.xy = r0.zw * g_render_target_dimensions.zw + float2(-0.5,-0.5);
    r2.xy = r2.xy + r2.xy;
    r1.w = dot(r2.xy, r2.xy);

    // Guard: 0 at the exact screen centre; log2(0) is -inf and -inf * 0 is NaN
    // when the falloff is 0. Stock's UNORM target flushed it, FP16 does not.
    r1.w = log2(max(r1.w, 1e-12f));
    r1.w = g_chromatic_aberration_falloff * r1.w;
    r1.w = exp2(r1.w);
    r1.w = ca_strength * r1.w;
    r1.w = r1.w * r1.w + 1;
    r1.w = r1.w * r1.w;
    r1.w = 1 / r1.w;
    r1.w = 1 + -r1.w;
    r2.xy = r0.zw * g_render_target_dimensions.zw + -r1.ww;
    r1.x = t_frame.SampleLevel(s_frame_s, r2.xy, 0).x;
    r0.zw = r0.zw * g_render_target_dimensions.zw + r1.ww;
    r1.y = t_frame.SampleLevel(s_frame_s, r0.zw, 0).z;
  }
  r2.xyzw = (int4)r0.xyxy + int4(0,-1,-1,0);
  r3.xyzw = float4(-1,-1,-1,-1) + g_render_target_dimensions.xyxy;
  r3.xyzw = (int4)r3.xyzw;
  r2.xyzw = max(int4(0,0,0,0), (int4)r2.xyzw);
  r2.xyzw = min((int4)r2.zwxy, (int4)r3.zwxy);
  r4.xy = r2.zw;
  r4.zw = float2(0,0);
  r4.xyz = t_frame.Load(r4.xyz).xyz;
  r2.zw = float2(0,0);
  r2.xyz = t_frame.Load(r2.xyz).xyz;
  r2.xyz = -r4.xyz + -r2.xyz;
  r2.xyz = r1.xzy * float3(5,5,5) + r2.xyz;
  r0.xyzw = (int4)r0.xyxy + int4(1,0,0,1);
  r0.xyzw = max(int4(0,0,0,0), (int4)r0.xyzw);
  r0.xyzw = min((int4)r0.zwxy, (int4)r3.zwxy);
  r3.xy = r0.zw;
  r3.zw = float2(0,0);
  r3.xyz = t_frame.Load(r3.xyz).xyz;
  r2.xyz = -r3.xyz + r2.xyz;
  r0.zw = float2(0,0);
  r0.xyz = t_frame.Load(r0.xyz).xyz;
  r0.xyz = r2.xyz + -r0.xyz;
  r0.xyz = r0.xyz + -r1.xzy;
  // Keep the lower clamp (Laplacian undershoot rings below zero), drop the upper
  // one in HDR so the sharpen does not crush the frame's headroom to UI white.
  // SDR: stock value, untouched. HDR: substitute a working base when the game's
  // value is the usual 0, then let SI.sharpening scale it.
  float sharpen_strength;
  if (HDR >= 0.5f) {
    float sharpen_base = (g_sharpening_strength > 1e-4f)
                           ? g_sharpening_strength
                           : kSharpenBaseFallback;
    sharpen_strength = sharpen_base * SI.sharpening;
  } else {
    sharpen_strength = g_sharpening_strength;
  }

  float3 sharpened = sharpen_strength * r0.xyz + r1.xzy;
  o0.xyz = (HDR >= 0.5f) ? max(sharpened, 0.f.xxx) : saturate(sharpened);
  o0.w = 1;
  return;
}