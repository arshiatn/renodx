// ---- Created with 3Dmigoto v1.3.16 on Sun Sep 20 01:08:46 2026
//
// TROY - vignette
//
// DECODED: this pass draws pure BLACK with alpha, nothing else. Writing
//     o0 = float4(0, 0, 0, 1 - vignette)
// through a standard alpha blend gives dst = dst * vignette, so the whole thing is a
// multiplicative darkening applied as a separate draw. Troy does it this way rather
// than baking it into the tonemapper like Rome II does.
//
//   d2  = squared distance from centre, in -1..1 screen space
//   v   = vignette_strength * pow(d2, vignette_falloff)
//   vig = 1 / (1 + v*v)^2          <- 1.0 at the centre, falls off outward
//
// The 0.996078432 threshold is 254/255: pixels the vignette would darken by less
// than one 8-bit step are discarded, which is just a fill-rate optimisation.
//
// SI.vignette lerps vig back toward 1.0 (no darkening), exactly like the Rome II
// shader does with its vignette_scale. 1.0 is stock, 0.0 is off - and at 0.0 every
// pixel lands above the discard threshold, so the pass costs nothing.
//
// Gated on HDR to match the addon (is_enabled = IsHDRMode) and the Rome II shader,
// where the slider only applies in the HDR paths.
//
// The slider still needs the in-game vignette setting on. If the game does not issue
// this draw, there is nothing here to scale.

cbuffer lense_flare_PS : register(b0)
{
  float time : packoffset(c0);
  float2 half_texel_offset : packoffset(c0.y);
  float vignette_strength : packoffset(c0.w);
  float vignette_falloff : packoffset(c1);
  float sun_flare_ps : packoffset(c1.y);
  float4 photomode_crop : packoffset(c2);
}



// 3Dmigoto declarations
#define cmp -
#include "../shared.h"


void main(
  float4 v0 : SV_Position0,
  float2 v1 : TEXCOORD0,
  out float4 o0 : SV_Target0)
{
  float4 r0;
  uint4 bitmask, uiDest;
  float4 fDest;

  r0.xy = saturate(photomode_crop.xz * v0.xy + photomode_crop.yw);
  r0.xy = half_texel_offset.xy + r0.xy;
  r0.xy = float2(-0.5,-0.5) + r0.xy;
  r0.xy = r0.xy + r0.xy;
  r0.x = dot(r0.xy, r0.xy);

  // log2(0) is -inf, and -inf * 0 is NaN if vignette_falloff is ever 0. The stock
  // UNORM target flushed that in the ROP; an FP16 target would blend NaN into the
  // frame. Half-texel offsets normally keep this above zero anyway.
  r0.x = log2(max(r0.x, 1e-12f));

  r0.x = vignette_falloff * r0.x;
  r0.x = exp2(r0.x);
  r0.x = vignette_strength * r0.x;
  r0.x = r0.x * r0.x + 1;
  r0.x = r0.x * r0.x;
  r0.x = 1 / r0.x;

  // User intensity. Lerp toward 1.0 = no darkening. Applied BEFORE the discard test
  // so that at 0.0 everything is culled instead of blending a zero-alpha quad.
  if (HDR >= 0.5f) {
    r0.x = lerp(1.f, r0.x, SI.vignette);
  }

  r0.xy = float2(1,0.996078432) + -r0.xx;
  r0.y = cmp(r0.y < 0);
  if (r0.y != 0) discard;
  r0.z = 0;
  o0.xyzw = r0.zzzx;
  return;
}