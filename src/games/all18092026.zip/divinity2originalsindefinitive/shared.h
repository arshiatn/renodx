#ifndef SRC_TEMPLATE_SHARED_H_
#define SRC_TEMPLATE_SHARED_H_

struct ShaderInjectData {
  float peak_white_nits;
  float diffuse_white_nits;
  float graphics_white_nits;
  float gamma_correction;
  float peak_test;
  float swap_chain_encoding;
  // float whiteclip;

  // float dof;
  // float uvdistort;
  float bloom;
  // float vignette;
  // float filmgrain;
  // float lut;
  // float ui;
  
  float tonemap_type;

  //FOR PSYCHOV30:
  float exposure;
  float highlights;
  float shadows;
  float contrast;
  float saturation;
  float cone_response_exponent;

  //TODO: ONLY FOR DEBUG DELETE LATER:
  float current_adaptive_state_bt709;
  float current_background_state_bt709;


  // Calibrated ACES
  float aces_exposure;
  float aces_contrast;
  float aces_highlights;
  float aces_shadows;
  float aces_saturation;
  float aces_highlight_saturation;

    // Calibrated ACES
  float aces_tweaked_exposure;
  float aces_tweaked_contrast;
  float aces_tweaked_highlights;
  float aces_tweaked_shadows;
  float aces_tweaked_saturation;
  float aces_tweaked_highlight_saturation;

  // For orange fires:
  float redcorrectionscale;
  float highlightfixamountx;
  float highlightfixamounty;
};

#define SI shader_injection
#define HDR_PEAK max(SI.peak_white_nits, SI.diffuse_white_nits) / max(SI.diffuse_white_nits, 0.0001f) //added guard
#define HDR_INTSCALING SI.diffuse_white_nits / SI.graphics_white_nits
#define HDR_STOPS log2(HDR_MAXEXPECTED / HDR_PEAK)
#define DOS2_CORRECT_HDR (SI.tonemap_type != 0.f )  //FIXED ACES OR TWEAKED ACES OR PSYCHO 

//This is for t01/t00 otherwise contrast slider still makes some differences.
//Traced them via devkit in the cbuffer of t00 and t01.
// Contrast 0.85 - 1.00 stays at 1516.4874f but goes up to 4xxx something at 1.1
#define DOS2_HDR_LUT_SHAPER_DOMAIN float2(5.4931616e-6f, 1516.4874f)


// Apply PsychoV30 from Test30.
// TODO: DELETE GRAY INPUT AND OUTPUT. IT WAS JUST FOR DEBUGGINGD
#define ApplyPsychoV30(color)                                                       \
  renodx_custom::tonemap::psycho30::psychotm_test30(                                \
      (color), HDR_PEAK, SI.exposure, SI.highlights, SI.shadows, SI.contrast,        \
      SI.saturation, 1.f, 100.f, 1.f, 1.f, 0, SI.cone_response_exponent,             \
      SI.current_adaptive_state_bt709.xxx, SI.current_background_state_bt709.xxx)



#ifndef __cplusplus
#if ((__SHADER_TARGET_MAJOR == 5 && __SHADER_TARGET_MINOR >= 1) || __SHADER_TARGET_MAJOR >= 6)
cbuffer shader_injection : register(b10, space50) {
#elif (__SHADER_TARGET_MAJOR < 5) || ((__SHADER_TARGET_MAJOR == 5) && (__SHADER_TARGET_MINOR < 1))
cbuffer shader_injection : register(b10) {
#endif
  ShaderInjectData shader_injection : packoffset(c0);
}

#include "../../shaders/renodx.hlsl"

#endif

#endif  // SRC_TEMPLATE_SHARED_H_
