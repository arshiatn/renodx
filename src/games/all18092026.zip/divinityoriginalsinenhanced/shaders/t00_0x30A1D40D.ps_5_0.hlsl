// ---- Created with 3Dmigoto v1.3.16 on Wed Aug 19 12:22:27 2026

cbuffer _Globals : register(b0)
{
  float4 Params : packoffset(c0);
  row_major float4x4 ColorMatrix : packoffset(c1);
  float3 SourceColor : packoffset(c5);
  float3 TargetColor : packoffset(c6);
}

Texture2D<float4> Base : register(t0);

// 3Dmigoto declarations
#define cmp -
//#include "./common.hlsl"
#include "./pragmap.hlsl"
#include "../psycho_test30.hlsli"

// define HDR_PEAK if missing
#ifndef HDR_PEAK
#define HDR_PEAK 2
#endif

void Rolloff(float3 color, float4 params, out float3 sdr, out float3 hdr) 
{
  // float4 r0, r1, r2, r3;
  // r0 = float4(color, 1);
  // r1.xyzw = float4(0.100000001,0.00999999978,0.300000012,11.1999998) * Params.yzzx;
  // r2.xyz = Params.xxx * r0.xyz + r1.xxx;
  // r2.xyz = r0.xyz * r2.xyz + r1.yyy;
  // r3.xyz = Params.xxx * r0.xyz + Params.yyy;
  // r0.xyz = r0.xyz * r3.xyz + r1.zzz;
  // r0.xyz = r2.xyz / r0.xyz;
  // r0.xyz = float3(-0.0333333351,-0.0333333351,-0.0333333351) + r0.xyz;
  // r0.w = r1.w + r1.x;
  // r0.w = r0.w * 11.1999998 + r1.y;
  // r1.x = Params.x * 11.1999998 + Params.y;
  // r1.x = r1.x * 11.1999998 + r1.z;
  // r0.w = r0.w / r1.x;
  // r0.w = -0.0333333351 + r0.w;
  // r0.xyzw = max(float4(0,0,0,0), r0.xyzw);
  // r0.xyz = r0.xyz / r0.www;
  // sdr = r0.xyz;
  
  // Main Menu Params.xyz: (0.48, 0.14, 0.62)
  float A = params.x;
  float B = params.y;
  float C = 0.100000001;
  float D = params.z;
  float E = 0.00999999978;
  float F = 0.300000012;
  float W = 11.1999998;
  float white_precompute = 1.f / ApplyCurve(W, A, B, C, D, E, F); // reciprocal of the curve at W

  // SDR (if unused, compiler will discard instructions)
  sdr = ApplyCurve(color, A, B, C, D, E, F) * white_precompute;
  sdr = max(0, sdr); // clean
  
  // Extended (fr on a stack no kapp this time)
  float coeffs[6] = { A, B, C, D, E, F }; // A-F
  Uncharted2::Config::Uncharted2ExtendedConfig uc2_config = Uncharted2::Config::CreateUncharted2ExtendedConfig(coeffs, white_precompute); // package into struct
  hdr = Uncharted2::ApplyExtended(color, uc2_config); // apply
}

/*
  Main Menu: (slight highlights & saturation boost)
  ColorMatrix { 1.0968, -0.08532, -0.01148,  0.00}
              {-0.0432,  1.05468, -0.01148,  0.00}
              {-0.0432, -0.08532,  1.12852,  0.00}
              { 0.00,    0.00,     0.00,     1.00} 
*/
// Gamma Encoded in & out (w is luminance for Anti-Aliasing)
float4 ColorMatrixGrading(float3 color, row_major float4x4 mat)
{
    // r0.xyz = min(float3(1,1,1), r0.xyz); // screw this
    // r0.w = 1;
    // r1.x = dot(ColorMatrix._m00_m01_m02_m03, r0.xyzw);
    // r1.y = dot(ColorMatrix._m10_m11_m12_m13, r0.xyzw);
    // r1.z = dot(ColorMatrix._m20_m21_m22_m23, r0.xyzw);
    // r0.w = dot(ColorMatrix._m30_m31_m32_m33, r0.xyzw); // luminance for Anti Aliasing

    float4 color1 = float4(color, 1);
    float4 result = float4(
        dot(mat._m00_m01_m02_m03, color1),
        dot(mat._m10_m11_m12_m13, color1),
        dot(mat._m20_m21_m22_m23, color1),
        dot(mat._m30_m31_m32_m33, color1) // luminance for Anti Aliasing
    );
    result = max(0, result); // clean
    return result;
}

// Gamma Encoded in & out
// - Higher "power" means less tinting / white path effect.
float3 Tint(float3 color, float3 targetColor, float3 sourceColor, float power = 2.0)
{
//   float4 r0,r1,r2,r3;
//   r1.xyz = color;
//   
//   r2.xyz = targetColor + r1.xyz;
//   r2.xyz = max(-1, r2.xyz);
//   r2.xyz = min(1, r2.xyz);
// 
//   r2.xyz = r2.xyz + -r1.xyz;
//   r3.xyz = -sourceColor.xyz + r1.xyz;
//   r1.w = dot(r3.xyz, r3.xyz);
//   r1.w = sqrt(r1.w);
//   r1.w = 1 + -r1.w;
//   r1.w = max(0, r1.w);
//   r1.w = r1.w * r1.w;
//   r0.xyz = r2.xyz * r1.www + r1.xyz;
//   return r0.xyz;

  // Compute delta and weight for tinting
  float3 delta = color + targetColor;
  delta = max(-1, delta);
  delta = min(1, delta);
  delta = delta + -color;

  float distance = length(color - sourceColor);
  float weight = max(0, 1.0 - distance);
  weight = pow(weight, power); // weight *= weight; 
  
  color = delta * weight + color; // apply
  color = max(0, color); // clean
  return color;
}

// Evaluates up to a 5th-degree polynomial
float EvalPolynomial(float x, float c5, float c4, float c3, float c2, float c1, float c0) {
  return ((((c5 * x + c4) * x + c3) * x + c2) * x + c1) * x + c0;
}

void main(
  float4 v0 : SV_Position0,
  float2 v1 : TexCoord0,
  out float4 o0 : SV_Target0)
{
  float4 r0,r1,r2,r3;
  uint4 bitmask, uiDest;
  float4 fDest;

  // temp init so compiler won't complain about uninitialized
  o0.w = 1; 
  r0.w = 1;

  // Color
  r0.xyz = Base.Load(int3(v0.xy, 0)).xyz;  // from r11g11b10_float, so only positive

  float3 HDR1 = r0.xyz;

  // setup HDR peak
  float p = HDR_PEAK;
  p = renodx::color::correct::Gamma(p, false, 2.2); // correct to sRGB

  // UC2/Hable for SDR and UC2 Extended for HDR
  float3 sdr, hdr;
  Rolloff(r0.xyz, Params, sdr, hdr); // Rolloff directly set sdr & hdr.

  // 0 => stock SDR, 1 => UC2 Extended + Pragmap, 2 => UC2 Extended + PsychoV25
  float tonemap_type = SI.tonemap_type;
  if (tonemap_type == 0) {
    r0.xyz = sdr;

    // Gamma Encode
    r0.xyz = pow(r0.xyz, 1.0 / 2.2);

    // Stock clamps to 1 before ColorMatrix
    r0.xyz = min(float3(1, 1, 1), r0.xyz);

    // Color Matrix Grading
    r0 = ColorMatrixGrading(r0.xyz, ColorMatrix);

    //tint
    r0.xyz = Tint(r0.xyz, TargetColor, SourceColor, 2.0);
  } else if (tonemap_type == 1) {
    r0.xyz = hdr;  // use hdr

    // Color Matrix Grading (saturation boost)
    r0.xyz = pow(max(hdr, 0.f), 1.f / 2.2f);
    r0 = ColorMatrixGrading(r0.xyz, ColorMatrix);  // w is luma for Anti-Aliasing
    r0.w = r0.w / (r0.w + 1);                      // rolloff luminance for AA

    // HDR Tonemap (to HDR peak w/ Hue Shift)
    r0.xyz = pow(r0.xyz, 2.2);  // Gamma Decode

    // old one from DabVeed:
    // r0.xyz = pragmap(r0.xyz, p, 0.785, 0.8, 0.05, 0.225);

    // ---ATN------------------------------------------------------------------------------------------------
    // Trying to match multiple points (p = peak/paper) to SDR's colors. Beach, Fire/candles and rain. Then making functions out of them as good as I can.
    // ------------------------------------------------------------------------------------------------------

    // If needed for later tuning again:
    // float customHS = SI.hueStrength;
    // float customBS = SI.blowoutStrength;
    // float customBH = SI.blowoutHarshness;
    // float customLRCS = SI.luminanceRolloffCompressionStrength;

    //--------- MY OLD POLYNOMIALS. I HAD TO CHANGE THEM TO MATCH SDR------
    // float c4 = -0.0000094503233f;
    // float c3 = 0.0005773442093f;
    // float c2 = -0.0016020061728f;
    // float c1 = 0.2572827013521f;
    // float c0 = 0.0373750734862f;
    // float stabilizeColor = (((c4 * p + c3) * p + c2) * p + c1) * p + c0;
    // stabilizeColor = clamp(stabilizeColor, 0.f, 4.0f);

    // for p<=1 -> 0.5, p=2 -> 0.675, p>=5 -> 1 ====> Geogebra:
    // c3 = 0.0291666666667f;
    // c2 = -0.25f;
    // c1 = 0.7208333333333f;
    // c0 = 0.0f;
    // float stabilizeBlowout = ((c3 * p + c2) * p + c1) * p + c0;
    // stabilizeBlowout = clamp(stabilizeBlowout, 0.1f, 1.0f);

    // // for p<=2 -> 0.05 and for p=5 -> 0.3 and p>5 -> more than 0.3 (99% of my reason to change this from fixed 0.05 was fire's inside.)
    // float stabilizeHarshness = (0.083333333f * p) - 0.11666667f;
    // stabilizeHarshness = clamp(stabilizeHarshness, 0.05f, 1.f);
    //-----------------------------------------------------------------------

    // A=(2,0.55), B=(5,1.15), C=(8,2), D=(12.5,2.5), E=(15,2.25)  with command TrendPoly({A,B,C,D,E},4)
    float stabilizeColor = EvalPolynomial(p, -0.0000048885271f, 0.0004223872835f, -0.0126676434676f, 0.1439545403157f, -0.3943482340705f, 0.857617690951f);
    stabilizeColor = clamp(stabilizeColor, 0.0f, 3.0f);

    // A=(1,0.4), B=(2,0.6), C=(5,0.75), D=(10,0.5), E=(12,0.375) with f(x)=TrendPoly({A,B,C,D,E},4)
    float stabilizeBlowout = EvalPolynomial(p, 0.0f, -0.0001551226551f, 0.00556998557f, -0.0747691197691f, 0.3876443001443f, 0.08170995671f);
    stabilizeBlowout = clamp(stabilizeBlowout, 0.35f, 1.0f);

    // A=(0,0.05), B=(1,0.05) , C=(2,0.05), D=(5,0.1), E=(7,0.05) with f(x)=TrendPoly({A,B,C,D,E},4)
    float stabilizeHarshness = EvalPolynomial(p, 0.0f, -0.0004166666667f, 0.0041666666667f, -0.0095833333333f, 0.0058333333333f, 0.05f);
    stabilizeHarshness = clamp(stabilizeHarshness, 0.0f, 0.3f);

    // A=(5,0.35), B=(2,0.01), C=(10,1) with f(x)=TrendPoly({A,B,C},2)
    float stabilizeLRCSC = EvalPolynomial(p, 0.0f, 0.0f, 0.0f, 0.0020833333333f, 0.09875f, -0.1958333333333f);
    stabilizeLRCSC = clamp(stabilizeLRCSC, 0.01f, 1.0f);

    // swap them out with customs from above to test
    r0.xyz = pragmap(r0.xyz,p,stabilizeColor,stabilizeBlowout,stabilizeHarshness,stabilizeLRCSC);

    r0.xyz = max(0, r0.xyz);        // clean
    r0.xyz = pow(r0.xyz, 1 / 2.2);  // Gamma Encode

    // Compress
    float scale = 1;
    r0.xyz = pow(r0.xyz, 2.2);  // Gamma Decode
    {
      // Max Channel (peak down to 1)
      float m = max(r0.x, max(r0.y, r0.z));
      float m1 = renodx::tonemap::Neutwo(m, 1, p);  // Info for myself: "By rolling off from peak to 1 by max channel, we scale the Tint / White Path right into HDR peak."
      scale = m > 0 ? m1 / m : 1;
      r0.xyz *= scale;
    }
    r0.xyz = pow(r0.xyz, 1 / 2.2);  // Gamma Encode

    // Tint / Path to White (SDR values only)
    r0.xyz = Tint(r0.xyz, TargetColor, SourceColor, 2.3);

    // Decompress
    r0.xyz = pow(r0.xyz, 2.2);  // Gamma Decode
    r0.xyz /= scale;
    r0.xyz = pow(r0.xyz, 1 / 2.2);  // Gamma Encode
  } else {
    // fixed it with chatgpt :U
    // He had the idea to end of upgradetonemap

    // Recreate the exact stock grade first. Applying the gamma-domain matrix
    // directly to the per-channel Hable extension makes warm highlights turn
    // increasingly red as their channels enter the extension at different
    // points. The bounded SDR result is the stable, peak-independent source
    // for the game's authored chroma and tint.
    float3 stock_graded_gamma = pow(max(sdr, 0.f), 1.f / 2.2f);
    stock_graded_gamma = min(stock_graded_gamma, 1.f.xxx);
    float4 stock_graded = ColorMatrixGrading(stock_graded_gamma, ColorMatrix);
    stock_graded.xyz = Tint(stock_graded.xyz, TargetColor, SourceColor, 2.f);
    float3 stock_graded_linear = pow(max(stock_graded.xyz, 0.f), 2.2f);
    r0.w = stock_graded.w / (stock_graded.w + 1.f);  // roll off luminance for AA

    // Preserve the stock chromatic direction while restoring only the extra
    // luminance carried by the Hable/Uncharted2 linear extension. This input
    // remains invariant when the display peak or paper white changes.
    r0.xyz = UpgradeToneMap(max(hdr, 0.f), max(sdr, 0.f), stock_graded_linear);

    // PsychoV30 tone mapper (Test30 implementation).
    r0.xyz = ApplyAttilaPsychoV30(r0.xyz);
    r0.xyz = renodx::color::gamma::EncodeSafe(r0.xyz, 2.2f);
  }
  
  // ATN: for both SDR/HDR
  // Fade to Black (HDR works)
  r1.xyzw = float4(0,0,0,1) + -r0.xyzw; // also scales luma for AA
  r2.x = saturate(Params.w);
  r0.xyzw = r2.xxxx * r1.xyzw + r0.xyzw;


  // UI SCALING
  r0.xyz = renodx::color::gamma::DecodeSafe(r0.xyz, 2.2f);
  r0.xyz *= SI.diffuse_white_nits / 80.f;
  r0.xyz = renodx::color::gamma::EncodeSafe(r0.xyz, 2.2f);


  // Keep PsychoV25's signed BT.709 representation of BT.2020 colors. The
  // legacy paths remain nonnegative exactly as before.
  r0 = renodx::math::ZeroNaN(r0);
  if (tonemap_type != 2) {
    r0 = max(0, r0);
  } else {
    r0.w = max(0, r0.w);
  }
  o0 = r0;
  return;
}
