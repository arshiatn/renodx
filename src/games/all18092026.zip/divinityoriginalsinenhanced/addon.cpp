/*
 * Copyright (C) 2024 Carlos Lopez
 * SPDX-License-Identifier: MIT
 */

#define ImTextureID ImU64

#define RENODX_MODS_SWAPCHAIN_VERSION 2
#define DEBUG_LEVEL_0

#include <string>

#include <deps/imgui/imgui.h>
#include <include/reshade.hpp>

#include <embed/shaders.h>

#include "../../mods/shader.hpp"
#include "../../mods/swapchain.hpp"
#include "../../utils/settings.hpp"
#include "./shared.h"

const std::string build_date = __DATE__;
const std::string build_time = __TIME__;

namespace {

ShaderInjectData shader_injection;
float current_settings_mode = 0.f;

bool IsAdvancedSettings() {
  return current_settings_mode >= 1.f;
}

bool IsUC2ExtendedPragmap() {
  return shader_injection.tonemap_type == 1.f;
}

bool IsPsychoV30() {
  return shader_injection.tonemap_type == 2.f;
}

bool ShowUC2ExtendedPragmapSettings() {
  return IsAdvancedSettings() && IsUC2ExtendedPragmap();
}

bool ShowPsychoSettings() {
  return IsAdvancedSettings() && IsPsychoV30();
}

#define UpgradeRTVReplaceShader(value)                                                                \
  {                                                                                                   \
      value,                                                                                          \
      {                                                                                               \
          .crc32 = value,                                                                             \
          .code = __##value,                                                                          \
          .on_draw = [](auto* cmd_list) {                                                             \
            auto rtvs = renodx::utils::swapchain::GetRenderTargets(cmd_list);                         \
            bool changed = false;                                                                     \
            for (auto rtv : rtvs) {                                                                   \
              changed = renodx::mods::swapchain::ActivateCloneHotSwap(cmd_list->get_device(), rtv);   \
            }                                                                                         \
            if (changed) {                                                                            \
              renodx::mods::swapchain::FlushDescriptors(cmd_list);                                    \
              renodx::mods::swapchain::RewriteRenderTargets(cmd_list, rtvs.size(), rtvs.data(), {0}); \
            }                                                                                         \
            return true; },                                                                           \
      },                                                                                              \
  }

renodx::mods::shader::CustomShaders custom_shaders = {

    // AA, between tonemapper and UI (SAME ORDER)
    UpgradeRTVReplaceShader(0x30A1D40D), // Tonemapper
    UpgradeRTVReplaceShader(0x9B114FEF), // Highlighting with cursor
    UpgradeRTVReplaceShader(0x83553BB1), // Highlighting with cursor
    UpgradeRTVReplaceShader(0x2400D20A), // Common post-pass
    UpgradeRTVReplaceShader(0x35F39F1D), // FXAA
    UpgradeRTVReplaceShader(0xB7FC46C3), // SMAA Pass 1
    UpgradeRTVReplaceShader(0x6AF33A9B), // SMAA Pass 2
    UpgradeRTVReplaceShader(0xFB839D33), // SMAA Pass 3
    UpgradeRTVReplaceShader(0xDDBCD866), // Vignette
    __ALL_CUSTOM_SHADERS,
    // --- REPLACE ONLY (SDR / UI / Untouched Elements) ---
    // CustomShaderEntry(0x2F56D195),       // PLAYER LIGHT
    // CustomShaderEntry(0x93AEBB93),       // for candles's fire
    // CustomShaderEntry(0x20163A55),       // UI Compositor
    // CustomShaderEntry(0x940951FA),      // For Godrays and some blurs
    // CustomShaderEntry(0xD39E39C8),      // LOCAL/Enemy LIGHT
    // CustomShaderEntry(0xED93F883),      // BAZIER'S FIRE SHADER
    // CustomShaderEntry(0x88B0D842),      // Bloom
};

// Settings //////////////////////////////////////////////////////////////////////////////////////////////////////////////////
renodx::utils::settings::Settings settings = {
    new renodx::utils::settings::Setting{
        .key = "SettingsMode",
        .binding = &current_settings_mode,
        .value_type = renodx::utils::settings::SettingValueType::INTEGER,
        .default_value = 0.f,
        .can_reset = false,
        .label = "Settings Mode",
        .labels = {"Simple", "Advanced"},
        .is_global = true,
    },
    // // Gamma Correction //////////////////////////////////////////////////////////////////////////////////////
    // new renodx::utils::settings::Setting{
    //     .value_type = renodx::utils::settings::SettingValueType::BULLET,
    //     .label = "Gamma correction off matches SDR.",
    //     .section = "Gamma Correction",
    // },
    // new renodx::utils::settings::Setting{
    //     .key = "gamma_correction",
    //     .binding = &shader_injection.gamma_correction,
    //     .value_type = renodx::utils::settings::SettingValueType::BOOLEAN,
    //     .default_value = 0.f,
    //     .label = "Gamma Correction",
    //     .section = "Gamma Correction",
    //     .tooltip = "Emulate Gamma 2.2 EOTF.\n(Attached to Scene Paper White.)",
    // },
    // new renodx::utils::settings::Setting{
    //     .value_type = renodx::utils::settings::SettingValueType::BUTTON,
    //     .label = "(Google Slides) Further Explanation & Test",
    //     .section = "Gamma Correction",
    //     .group = "button-line-1",
    //     .on_change = []() {
    //       renodx::utils::platform::LaunchURL("https://docs.google.com/presentation/d/e/2PACX-1vSXeLHlbm6repcS7fels1-SXYGRmzziRrnuJ8nDO8J5rsWV3dT1-nVyCKp0Tj_stwx-9qlCI-N6rYIT/pub?start=false&loop=false&slide=id.g3e007eafba8_0_0");
    //     },
    // },
    // Peak //////////////////////////////////////////////////////////////////////////////////////
    // new renodx::utils::settings::Setting{
    //     .key = "peak_test",
    //     .binding = &shader_injection.peak_test,
    //     .value_type = renodx::utils::settings::SettingValueType::BOOLEAN,
    //     .default_value = 0.f,
    //     .label = "Calibration",
    //     .section = "Peak",
    //     .tooltip = "3 rectangles within a large one.\n\n- Left: Not Visible.\n- Middle: Barely Visible.\n- Right: Easily Visible.\n\n(Ofc, you can always set lower to personal pref.)",
    // },
    new renodx::utils::settings::Setting{
        .key = "peak_white_nits",
        .binding = &shader_injection.peak_white_nits,
        .default_value = 400.f,
        .can_reset = false,
        .label = "Peak",
        .section = "General",
        .tooltip = "Maximum brightness output in nits.",
        .min = 400.f,
        .max = 10000.f,
        // .format = "%.2f",
        // .parse = [](float value) { return value / 80.f; },
    },
    // new renodx::utils::settings::Setting{
    //     .key = "whiteclip",
    //     .binding = &shader_injection.whiteclip,
    //     .default_value = 1.f,
    //     .label = "Clip",
    //     .section = "Peak",
    //     .tooltip = "Raise to increase clipping in highlights.",
    //     .min = 0.1f,
    //     .max = 2.f,
    //     .format = "%.2f",
    // },
    // Paper White //////////////////////////////////////////////////////////////////////////////////////
    new renodx::utils::settings::Setting{
        .key = "diffuse_white_nits",
        .binding = &shader_injection.diffuse_white_nits,
        .default_value = 203.f,
        .label = "Scene (Paper White)",
        .section = "General",
        .tooltip = "Brightness of the scene/game.",
        .min = 1.f,
        .max = 500.f,
        // .format = "%.2f",
        // .parse = [](float value) { return value / 80.f; },
    },
    new renodx::utils::settings::Setting{
        .key = "graphics_white_nits",
        .binding = &shader_injection.graphics_white_nits,
        .default_value = 203.f,
        .label = "UI",
        .section = "General",
        .tooltip = "Brightness of UI and HUD in nits.",
        .min = 1.f,
        .max = 500.f,
        // .format = "%.2f",
        // .parse = [](float value) { return value / 80.f; },
    },
    new renodx::utils::settings::Setting{
        .key = "tonemap_type",
        .binding = &shader_injection.tonemap_type,
        .value_type = renodx::utils::settings::SettingValueType::INTEGER,
        .default_value = 2.f,
        .can_reset = true,
        .label = "Rendering Mode",
        .section = "General",
        .tooltip = "SDR is native, Psycho stays true to original colors, pragmap alters the colors",
        .labels = {"SDR (UC2)", "HDR (UC2 Extended + Pragmap)", "HDR (UC2 Extended + PsychoV30)"},
    },

    // Presets //////////////////////////////////////////////////////////////////////////////////////
    new renodx::utils::settings::Setting{
        .value_type = renodx::utils::settings::SettingValueType::BUTTON,
        .label = "Default",
        .section = "Presets",
        .group = "preset-buttons-0",
        .on_change = []() {
            // General
            renodx::utils::settings::UpdateSetting("tonemap_type", 2.f);

            // Psycho V30
            renodx::utils::settings::UpdateSetting("exposure", 1.00f);
            renodx::utils::settings::UpdateSetting("highlights", 1.00f);
            renodx::utils::settings::UpdateSetting("purity_scale", 1.00f);
            renodx::utils::settings::UpdateSetting("shadows", 1.00f);
            renodx::utils::settings::UpdateSetting("contrast", 1.00f);
            renodx::utils::settings::UpdateSetting("cone_response_exponent", 1.00f);

            // Extra for pragmap only
            renodx::utils::settings::UpdateSetting("firehighlightmultiplier", 0.50f);
            renodx::utils::settings::UpdateSetting("candlehighlightmultiplier", 1.00f);

            // Extra for Psycho preset only
            renodx::utils::settings::UpdateSetting("firehighlightmultiplierpsycho", 0.00f);
            renodx::utils::settings::UpdateSetting("candlehighlightmultiplierpsycho", 1.00f);

            // Extra
            renodx::utils::settings::UpdateSetting("bloom", 1.00f);
            renodx::utils::settings::UpdateSetting("vignette", 1.00f);
            renodx::utils::settings::UpdateSetting("godrays", 1.00f);

            // Game-Specific Settings
            renodx::utils::settings::UpdateSetting("ui", 1.00f);
            renodx::utils::settings::UpdateSetting("playerLightIntensity", 1.00f);
            renodx::utils::settings::UpdateSetting("playerLightRadius", 1.00f);
        },
    },
        new renodx::utils::settings::Setting{
        .value_type = renodx::utils::settings::SettingValueType::BUTTON,
        .label = "What I use:",
        .section = "Presets",
        .group = "preset-buttons-0",
        .on_change = []() {
            // General
            renodx::utils::settings::UpdateSetting("tonemap_type", 2.f);

            // Psycho V30
            renodx::utils::settings::UpdateSetting("exposure", 1.00f);
            renodx::utils::settings::UpdateSetting("highlights", 1.00f);
            renodx::utils::settings::UpdateSetting("purity_scale", 1.00f);
            renodx::utils::settings::UpdateSetting("shadows", 1.00f);
            renodx::utils::settings::UpdateSetting("contrast", 1.00f);
            renodx::utils::settings::UpdateSetting("cone_response_exponent", 1.00f);

            // Extra for Psycho preset only
            renodx::utils::settings::UpdateSetting("firehighlightmultiplierpsycho", 1.00f);
            renodx::utils::settings::UpdateSetting("candlehighlightmultiplierpsycho", 2.4f);

            // Extra
            renodx::utils::settings::UpdateSetting("bloom", 1.00f);
            renodx::utils::settings::UpdateSetting("vignette", 1.00f);
            renodx::utils::settings::UpdateSetting("godrays", 1.00f);

            // Game-Specific Settings
            renodx::utils::settings::UpdateSetting("ui", 1.00f);
            renodx::utils::settings::UpdateSetting("playerLightIntensity", 0.00f);
            renodx::utils::settings::UpdateSetting("playerLightRadius", 1.00f);
        },
    },
    // PsychoV30 //////////////////////////////////////////////////////////////////////////////////////
    new renodx::utils::settings::Setting{
        .key = "exposure",
        .binding = &shader_injection.exposure,
        .value_type = renodx::utils::settings::SettingValueType::FLOAT,
        .default_value = 1.0f,
        .label = "Exposure",
        .section = "Psycho V30",
        .min = 0.00f,
        .max = 2.00f,
        .format = "%.2f",
        .is_enabled = IsPsychoV30,
        .is_visible = ShowPsychoSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "highlights",
        .binding = &shader_injection.highlights,
        .value_type = renodx::utils::settings::SettingValueType::FLOAT,
        .default_value = 1.0f,
        .label = "Highlights",
        .section = "Psycho V30",
        .min = 0.00f,
        .max = 2.00f,
        .format = "%.2f",
        .is_enabled = IsPsychoV30,
        .is_visible = ShowPsychoSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "purity_scale",
        .binding = &shader_injection.purity_scale,
        .value_type = renodx::utils::settings::SettingValueType::FLOAT,
        .default_value = 1.0f,
        .label = "Saturation / Purity",
        .section = "Psycho V30",
        .min = 0.00f,
        .max = 2.00f,
        .format = "%.2f",
        .is_enabled = IsPsychoV30,
        .is_visible = ShowPsychoSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "shadows",
        .binding = &shader_injection.shadows,
        .value_type = renodx::utils::settings::SettingValueType::FLOAT,
        .default_value = 1.0f,
        .label = "Shadows",
        .section = "Psycho V30",
        .min = 0.00f,
        .max = 2.00f,
        .format = "%.2f",
        .is_enabled = IsPsychoV30,
        .is_visible = ShowPsychoSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "contrast",
        .binding = &shader_injection.contrast,
        .value_type = renodx::utils::settings::SettingValueType::FLOAT,
        .default_value = 1.0f,
        .label = "Contrast",
        .section = "Psycho V30",
        .min = 0.00f,
        .max = 2.00f,
        .format = "%.2f",
        .is_enabled = IsPsychoV30,
        .is_visible = ShowPsychoSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "cone_response_exponent",
        .binding = &shader_injection.cone_response_exponent,
        .value_type = renodx::utils::settings::SettingValueType::FLOAT,
        .default_value = 1.0f,
        .label = "Cone Response Exponent",
        .section = "Psycho V30",
        .min = 0.00f,
        .max = 2.00f,
        .format = "%.2f",
        .is_enabled = IsPsychoV30,
        .is_visible = ShowPsychoSettings,
    },
    // Extra //////////////////////////////////////////////////////////////////////////////////////
    // new renodx::utils::settings::Setting{
    //     .key = "dof",
    //     .binding = &shader_injection.dof,
    //     .value_type = renodx::utils::settings::SettingValueType::BOOLEAN,
    //     .default_value = 1.f,
    //     .label = "Depth of Field",
    //     .section = "Extra",
    //     .tooltip = "Toggle depth of field effect.",
    // },
    // new renodx::utils::settings::Setting{
    //     .key = "uvdistort",
    //     .binding = &shader_injection.uvdistort,
    //     .value_type = renodx::utils::settings::SettingValueType::BOOLEAN,
    //     .default_value = 1.f,
    //     .label = "Lens Distortion",
    //     .section = "Extra",
    //     .tooltip = "Toggle lens distortion on color.",
    // },
        new renodx::utils::settings::Setting{
        .key = "firehighlightmultiplier",
        .binding = &shader_injection.firehighlightmultiplier,
        .default_value = 0.50f,
        .label = "Fire Highlights",
        .section = "Extra for pragmap only",
        .tooltip = "Fire Highlights EXTRA ON TOP of my highlights.",
        .min = 0.50f,
        .max = 1.50f,
        .format = "%.2f",
        .is_enabled = IsUC2ExtendedPragmap,
        .is_visible = ShowUC2ExtendedPragmapSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "candlehighlightmultiplier",
        .binding = &shader_injection.candlehighlightmultiplier,
        .default_value = 1.0f,
        .label = "Candle/staff/small particles Highlights",
        .section = "Extra for pragmap only",
        .tooltip = "Candle/staff/small particles Highlights EXTRA ON TOP of my highlights.",
        .min = 0.50f,
        .max = 1.50f,
        .format = "%.2f",
        .is_enabled = IsUC2ExtendedPragmap,
        .is_visible = ShowUC2ExtendedPragmapSettings,
    },

    new renodx::utils::settings::Setting{
        .key = "firehighlightmultiplierpsycho",
        .binding = &shader_injection.firehighlightmultiplierpsycho,
        .value_type = renodx::utils::settings::SettingValueType::INTEGER,
        .default_value = 0.f,
        .can_reset = true,
        .label = "Bazier/Some Fire Highlights",
        .section = "Experimental",
        .tooltip = "Bazier/Some Fire booster. 0 is Stock",
        .labels = {"Booster Off", "Booster On"},
        .is_enabled = IsPsychoV30,
        .is_visible = ShowPsychoSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "candlehighlightmultiplierpsycho",
        .binding = &shader_injection.candlehighlightmultiplierpsycho,
        .default_value = 1.0f,
        .label = "Candle/Rain/small particles Highlights",
        .section = "Experimental",
        .tooltip = "Candle/staff/small particles Highlights multiplier. 1.0 is stock",
        .min = 1.0f,
        .max = 10.0f,
        .format = "%.1f",
        .is_enabled = IsPsychoV30,
        .is_visible = ShowPsychoSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "bloom",
        .binding = &shader_injection.bloom,
        .default_value = 1.f,
        .label = "Bloom",
        .section = "Extra",
        .tooltip = "Bloom multiplier.",
        .min = 0.f,
        .max = 5.f,
        .format = "%.1f",
        .is_visible = IsAdvancedSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "vignette",
        .binding = &shader_injection.vignette,
        .default_value = 1.f,
        .label = "Vignette",
        .section = "Extra",
        .tooltip = "Multiplier on vignette mask.",
        .min = 0.f,
        .max = 2.f,
        .format = "%.2f",
        .is_visible = IsAdvancedSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "godrays",
        .binding = &shader_injection.godrays,
        .default_value = 1.f,
        .label = "Godrays",
        .section = "Extra",
        .tooltip = "Godrays multiplier.",
        .min = 0.f,
        .max = 10.f,
        .format = "%.1f",
        .is_visible = IsAdvancedSettings,
    },
    // new renodx::utils::settings::Setting{
    //     .key = "filmgrain",
    //     .binding = &shader_injection.filmgrain,
    //     .default_value = 1.f,
    //     .label = "Film Grain",
    //     .section = "Extra",
    //     .tooltip = "Multiplier on film grain effect.",
    //     .min = 0.f,
    //     .max = 1.f,
    //     .format = "%.2f",
    // },
    // new renodx::utils::settings::Setting{
    //     .key = "lut",
    //     .binding = &shader_injection.lut,
    //     .value_type = renodx::utils::settings::SettingValueType::BOOLEAN,
    //     .default_value = 1.f,
    //     .label = "LUT (Debug)",
    //     .section = "Extra",
    //     .tooltip = "Toggle color grading via LUT.",
    // },
    new renodx::utils::settings::Setting{
        .key = "ui",
        .binding = &shader_injection.ui,
        .value_type = renodx::utils::settings::SettingValueType::BOOLEAN,
        .default_value = 1.f,
        .label = "UI",
        .section = "Game-Specific Settings",
        .tooltip = "Toggle UI elements, enough for screenshot in pause menu.",
        .labels = {"Off", "On"},
        .is_visible = IsAdvancedSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "playerLightIntensity",
        .binding = &shader_injection.player_light_intensity,
        .default_value = 1.f,
        .label = "Player Light Intensity",
        .section = "Game-Specific Settings",
        .tooltip = "Adjusts the brightness of player (and torches in main menu).",
        .min = 0.f,
        .max = 2.f,
        .format = "%.1f",
        .is_visible = IsAdvancedSettings,
    },
    new renodx::utils::settings::Setting{
        .key = "playerLightRadius",
        .binding = &shader_injection.local_light_intensity,
        .default_value = 1.f,
        .label = "Local/Enemy Light Intensity",
        .section = "Game-Specific Settings",
        .tooltip = "Adjusts the brightness of torches, player and enemies.",
        .min = 0.f,
        .max = 2.f,
        .format = "%.1f",
        .is_visible = IsAdvancedSettings,
    },

/*     // FPS Limit //////////////////////////////////////////////////////////////////////////////////////
    new renodx::utils::settings::Setting{
        .key = "fps_limit",
        .binding = &renodx::utils::swapchain::fps_limit,
        .default_value = 0.f,
        .can_reset = true,
        .label = "Value",
        .section = "FPS Limit",
        .min = 0.f,
        .max = 240.f,
    }, */
/*     new renodx::utils::settings::Setting{
        .key = "hueStrength",
        .binding = &shader_injection.hueStrength,
        .default_value = 0.55f,
        .can_reset = true,
        .label = "Hue Strength",
        .section = "PragMap Tuning",
        .min = 0.0f,
        .max = 10.0f,
        .format = "%.3f",
    },
    new renodx::utils::settings::Setting{
        .key = "blowoutStrength",
        .binding = &shader_injection.blowoutStrength,
        .default_value = 0.75f,
        .can_reset = true,
        .label = "Blowout Strength",
        .section = "PragMap Tuning",
        .min = 0.0f,
        .max = 1.0f,
        .format = "%.3f",
    },
    new renodx::utils::settings::Setting{
        .key = "blowoutHarshness",
        .binding = &shader_injection.blowoutHarshness,
        .default_value = 0.0f,
        .can_reset = true,
        .label = "Blowout Harshness",
        .section = "PragMap Tuning",
        .min = 0.0f,
        .max = 1.0f,
        .format = "%.3f",
    },
    new renodx::utils::settings::Setting{
        .key = "luminanceRolloff",
        .binding = &shader_injection.luminanceRolloffCompressionStrength,
        .default_value = 1.0f,
        .can_reset = true,
        .label = "Rolloff Compression",
        .section = "PragMap Tuning",
        .min = 0.01f,
        .max = 1.0f,
        .format = "%.3f",
    }, */
};


bool initialized = false;

}  // namespace

// DllMain //////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void OnInitSwapchain(reshade::api::swapchain* swapchain, bool resize) {
  auto peak = renodx::utils::swapchain::GetPeakNits(swapchain);
  auto white_level = 203.f;
  if (!peak.has_value()) {
    peak = 1000.f;
  }

  // find and set
  for (auto& setting : settings) {
    if (setting->binding != &shader_injection.peak_white_nits) continue;
    setting->default_value = peak.value();
    setting->max = std::max(peak.value(), setting->max);
    setting->can_reset = true;
    break;
  }

  // settings[3]->default_value = renodx::utils::swapchain::ComputeReferenceWhite(peak.value());
}

extern "C" __declspec(dllexport) constexpr const char* NAME = "RenoDX";
extern "C" __declspec(dllexport) constexpr const char* DESCRIPTION = "RenoDX - Divinity: Original Sin Enhanced Edition by ATN"; //TODO: change me!

BOOL APIENTRY DllMain(HMODULE h_module, DWORD fdw_reason, LPVOID lpv_reserved) {
  switch (fdw_reason) {
    case DLL_PROCESS_ATTACH:
      if (!reshade::register_addon(h_module)) return FALSE;

      if (!initialized) {
        // Shaders cb
        renodx::mods::shader::expected_constant_buffer_space = 50;
        renodx::mods::shader::expected_constant_buffer_index = 10;

        // Swapchain cb
        renodx::mods::swapchain::expected_constant_buffer_index = 10;
        renodx::mods::swapchain::expected_constant_buffer_space = 50;
        
        // Swapchain upgrade settings
        renodx::mods::swapchain::use_resource_cloning = true;
        renodx::mods::swapchain::force_borderless = false;
        renodx::mods::swapchain::prevent_full_screen = true;
        
        // Proxy Shaders
        renodx::mods::swapchain::swap_chain_proxy_shaders = {
            {
                reshade::api::device_api::d3d11,
                {
                    .vertex_shader = __swap_chain_proxy_vertex_shader_dx11,
                    .pixel_shader = __swap_chain_proxy_pixel_shader_dx11,
                },
            },
        };   

         // Resource Upgrades
        #if RENODX_MODS_SWAPCHAIN_VERSION == 2
            renodx::mods::swapchain::resource_upgrade_infos.push_back({
        #else
            renodx::mods::swapchain::swap_chain_upgrade_targets.push_back({
        #endif
            .old_format = reshade::api::format::r8g8b8a8_unorm,
            .new_format = reshade::api::format::r16g16b16a16_float,
            .ignore_size = true,
            .use_resource_view_cloning = true, //TODO: needed?
            .use_resource_view_hot_swap = true,
            .aspect_ratio = renodx::mods::swapchain::SwapChainUpgradeTarget::ANY,
            .usage_include = reshade::api::resource_usage::render_target,
        });

        // Appended Settings (HDR10)
        {
            auto* setting = new renodx::utils::settings::Setting{
                .key = "SwapChainEncoding",
                .value_type = renodx::utils::settings::SettingValueType::INTEGER,
                .default_value = 1.f,
                .label = "Output",
                .section = "Output (Restart Required)",
                .tooltip = "HDR10: 10bit, enough quality (banding?).\nscRGB: 16bit, overkill quality.",
                .labels = {"HDR10", "scRGB"},
                .is_global = true,
            };
            renodx::utils::settings::LoadSetting(renodx::utils::settings::global_name, setting);
            auto v = setting->GetValue();
            shader_injection.swap_chain_encoding = v;
            renodx::mods::swapchain::SetUseHDR10(v == 0);
            settings.push_back(setting);
        }

        // Appended Settings (About)
        {
            auto* s1 = new renodx::utils::settings::Setting{
                .value_type = renodx::utils::settings::SettingValueType::TEXT,
                .label = "Build Date: " + build_date + " - " + build_time,
                .section = "About",
            };
            settings.push_back(s1);
        }

        reshade::register_event<reshade::addon_event::init_swapchain>(OnInitSwapchain);  // peak nits

        initialized = true;
      }

      break;
    case DLL_PROCESS_DETACH:
      reshade::unregister_event<reshade::addon_event::init_swapchain>(OnInitSwapchain);  // peak nits
      reshade::unregister_addon(h_module);
      break;
  }

  renodx::utils::settings::Use(fdw_reason, &settings, nullptr);
  renodx::mods::swapchain::Use(fdw_reason, &shader_injection);
  renodx::mods::shader::Use(fdw_reason, custom_shaders, &shader_injection);

  return TRUE;
}
