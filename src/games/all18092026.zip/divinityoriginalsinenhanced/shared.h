#ifndef SRC_TEMPLATE_SHARED_H_
#define SRC_TEMPLATE_SHARED_H_

struct ShaderInjectData {
  float peak_white_nits;
  float diffuse_white_nits;
  float graphics_white_nits;
  float gamma_correction;
  float peak_test;
  float swap_chain_encoding;
  float tonemap_type; // 0 = SDR, 1 = UC2 Extended/Pragmap, 2 = PsychoV30
  
  
  // PRAGMAP DEBUG TUNING
  // float hueStrength;
  // float blowoutStrength;
  // float blowoutHarshness;
  // float luminanceRolloffCompressionStrength;
  // ----------------------------

  
  // float whiteclip;
  // float dof;
  // float uvdistort;
  // float filmgrain;
  // float lut;
  
  float vignette;
  float bloom;
  float godrays; 
  float ui; //visibility fo UI
  float firehighlightmultiplier;
  float firehighlightmultiplierpsycho;
  float candlehighlightmultiplier;  
  float candlehighlightmultiplierpsycho;  
  float player_light_intensity;
  float local_light_intensity;

  //For PsychoV30
  float exposure;
  float highlights;
  float shadows;
  float cone_response_exponent;
  float contrast;
  float purity_scale;
};

#define SI shader_injection
#define HDR_PEAK SI.peak_white_nits / SI.diffuse_white_nits
#define HDR_INTSCALING SI.diffuse_white_nits / SI.graphics_white_nits
#define HDR_STOPS log2(HDR_MAXEXPECTED / HDR_PEAK)

// PsychoV30 keeps a fixed 1.0 exposure, 0.18 input/output anchors, full target
// gamut projection, BT.2020 target volume, and automatic compression. The
// compatibility-only parameters between purity and cone response stay neutral.
#define ApplyAttilaPsychoV30(color)                                               \
  renodx_custom::tonemap::psycho30::psychotm_test30(                             \
      (color), HDR_PEAK, SI.exposure, SI.highlights, SI.shadows, SI.contrast,            \
      SI.purity_scale, 1.f, 100.f, 1.f, 1.f, 0, SI.cone_response_exponent)

//extra
#define GODRAYS SI.godrays
#define LOCAL_LIGHT_INTENSITY SI.local_light_intensity
#define PLAYER_LIGHT_INTENSITY SI.player_light_intensity

#ifndef __cplusplus
#if ((__SHADER_TARGET_MAJOR == 5 && __SHADER_TARGET_MINOR >= 1) || __SHADER_TARGET_MAJOR >= 6)
cbuffer shader_injection : register(b10, space50) { // Changed to b10
#elif (__SHADER_TARGET_MAJOR < 5) || ((__SHADER_TARGET_MAJOR == 5) && (__SHADER_TARGET_MINOR < 1))
cbuffer shader_injection : register(b10) {          // Changed to b10
#endif
  ShaderInjectData shader_injection : packoffset(c0);
}

#include "../../shaders/renodx.hlsl"

#endif

#endif  // SRC_TEMPLATE_SHARED_H_
