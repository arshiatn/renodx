#include "./shared.h"

// DX11 proxy (the game is DX9): the game's back buffer (FP16 copy) to the HDR swap chain.
// Back buffer: gamma 2.2, UI white = 1. The scene is already scaled to Paper White / UI.

Texture2D t0 : register(t0);
SamplerState s0 : register(s0);

float4 main(float4 vpos : SV_POSITION, float2 uv : TEXCOORD0) : SV_TARGET {
  float3 x = t0.Sample(s0, uv).xyz;

  // Signed: PsychoV uses signed BT.709 to represent BT.2020.
  x = renodx::color::gamma::DecodeSafe(x);

  // HDR10
  if (SI.swap_chain_encoding == 0) {
    x = renodx::color::bt2020::from::BT709(x);
    x *= SI.graphics_white_nits / 10000.f;
    x = renodx::color::pq::EncodeSafe(x);  // clamps below 0 in BT.2020
  }
  // scRGB
  else {
    x *= SI.graphics_white_nits / 80.f;
  }

  return float4(x, 1.f);
}
