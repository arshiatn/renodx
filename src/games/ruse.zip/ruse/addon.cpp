/*
 * Copyright (C) 2024 Carlos Lopez
 * SPDX-License-Identifier: MIT
 */

// R.U.S.E. (64-bit, DX9). Needs the in-game HDR setting on: that path renders a 10-bit
// scene with bloom (postprocess00, 0x232EB5DF). The game has no tonemapper, its 8-bit back
// buffer clips at 1. We keep the scene in FP16 and tonemap in postprocess00.
// DX9 has no HDR swap chain: RenoDX presents through a DX11 one (device proxy).

#define ImTextureID ImU64

#define RENODX_MODS_SWAPCHAIN_VERSION 2
#define DEBUG_LEVEL_0

#include <algorithm>
#include <string>

#include <deps/imgui/imgui.h>
#include <include/reshade.hpp>

#include <embed/shaders.h>

#include "../../mods/shader.hpp"
#include "../../mods/swapchain.hpp"
#include "../../utils/settings.hpp"
#include "./shared.h"

constexpr char BUILD_DATE[] = __DATE__;
constexpr char BUILD_TIME[] = __TIME__;

namespace {

ShaderInjectData shader_injection;
float current_settings_mode = 0.f;

bool IsAdvancedSettings() {
  return current_settings_mode >= 1.f;
}

bool IsExtendedMode() {
  return shader_injection.hdr == 1.f && current_settings_mode == 1;
}

bool IsPsychoMode() {
  return shader_injection.hdr == 2.f && current_settings_mode == 1;
}

// Extra sliders: both HDR modes.
bool IsHDRMode() {
  return shader_injection.hdr >= 1.f && current_settings_mode == 1;
}

void ApplyResetPreset() {
  // Peak / Paper White / UI brightness, Settings Mode, and output settings are preserved.
  renodx::utils::settings::UpdateSettings({
      {"tonemapper", 1.f},

      // PsychoV30
      {"exposure", 1.f},
      {"highlights", 1.f},
      {"shadows", 1.f},
      {"contrast", 1.f},
      {"purity_scale", 1.f},
      {"cone_response_exponent", 1.f},

      // HDR Extended / user grading
      {"exposure_tpm", 1.f},
      {"highlights_tpm", 1.f},
      {"shadows_tpm", 1.f},
      {"contrast_tpm", 1.f},
      {"saturation_tpm", 1.f},

      // Extra
      {"bloom", 1.f},
      {"vignette", 1.f},
  });
}

void ApplyPsychoRecommended() {
  // Only PsychoV30 controls are changed. Peak / Paper White / UI brightness
  // and unrelated controls are preserved.
  renodx::utils::settings::UpdateSettings({
      {"tonemapper", 2.f},
      {"exposure", 1.f},
      {"highlights", 1.f},
      {"shadows", 1.f},
      {"contrast", 1.f},
      {"purity_scale", 1.f},
      {"cone_response_exponent", 1.f},
  });
}

renodx::mods::shader::CustomShaders custom_shaders;
renodx::utils::settings::Settings settings;

void BuildRuntimeData() {
  custom_shaders = {
      __ALL_CUSTOM_SHADERS,
  };

  // Settings ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  settings = {
      new renodx::utils::settings::Setting{
          .key = "SettingsMode",
          .binding = &current_settings_mode,
          .value_type = renodx::utils::settings::SettingValueType::INTEGER,
          .default_value = 0.f,
          .can_reset = false,
          .label = "Settings Mode",
          .labels = {"Simple", "Advanced"},
          .is_global = true,
      },
      new renodx::utils::settings::Setting{
          .key = "peak_white_nits",
          .binding = &shader_injection.peak_white_nits,
          .default_value = 1000.f,
          .can_reset = false,
          .label = "Peak",
          .section = "General",
          .tooltip = "Maximum brightness output in nits.",
          .min = 400.f,
          .max = 10000.f,
      },
      new renodx::utils::settings::Setting{
          .key = "diffuse_white_nits",
          .binding = &shader_injection.diffuse_white_nits,
          .default_value = 203.f,
          .label = "Paper White",
          .section = "General",
          .tooltip = "Brightness of the scene/game.",
          .min = 1.f,
          .max = 500.f,
      },
      new renodx::utils::settings::Setting{
          .key = "graphics_white_nits",
          .binding = &shader_injection.graphics_white_nits,
          .default_value = 203.f,
          .label = "UI",
          .section = "General",
          .tooltip = "Brightness of UI and HUD in nits.",
          .min = 1.f,
          .max = 500.f,
      },
      new renodx::utils::settings::Setting{
          .key = "tonemapper",
          .binding = &shader_injection.hdr,
          .value_type = renodx::utils::settings::SettingValueType::INTEGER,
          .default_value = 1.f,
          .label = "Rendering Mode",
          .section = "General",
          .tooltip = "Needs the in-game HDR setting on.\n"
                     "SDR: the game's original picture (no tonemapper, highlights clip).\n"
                     "HDR (Extended): the original picture, clipped highlights restored up to Peak.\n"
                     "HDR (PsychoV30): PsychoV30 as tonemapper.",
          .labels = {"SDR", "HDR (Extended)", "HDR (PsychoV30)"},
      },
      new renodx::utils::settings::Setting{
          .value_type = renodx::utils::settings::SettingValueType::BUTTON,
          .label = "Recommended (PsychoV30)",
          .section = "Presets",
          .group = "preset-line-1",
          .tooltip = "Recommended Setting is PsychoV30\n"
                     "Peak, Paper White, UI brightness, and unrelated controls are preserved.",
          .on_change = []() {
            ApplyPsychoRecommended();
          },
      },
      new renodx::utils::settings::Setting{
          .value_type = renodx::utils::settings::SettingValueType::BUTTON,
          .label = "Reset",
          .section = "Presets",
          .group = "preset-line-2",
          .tooltip = "Resets active image controls to their defaults.\n"
                     "Peak, Paper White, UI brightness, Settings Mode, and output settings are preserved.",
          .on_change = []() {
            ApplyResetPreset();
          },
      },

      // Psycho V30 //////////////////////////////////////////////////////////////////////////////
      new renodx::utils::settings::Setting{
          .key = "exposure",
          .binding = &shader_injection.exposure,
          .value_type = renodx::utils::settings::SettingValueType::FLOAT,
          .default_value = 1.00f,
          .label = "Exposure",
          .section = "Psycho V30",
          .min = 0.00f,
          .max = 2.00f,
          .format = "%.2f",
          .is_enabled = IsPsychoMode,
          .is_visible = IsPsychoMode,
      },
      new renodx::utils::settings::Setting{
          .key = "highlights",
          .binding = &shader_injection.highlights,
          .value_type = renodx::utils::settings::SettingValueType::FLOAT,
          .default_value = 1.00f,
          .label = "Highlights",
          .section = "Psycho V30",
          .min = 0.00f,
          .max = 2.00f,
          .format = "%.2f",
          .is_enabled = IsPsychoMode,
          .is_visible = IsPsychoMode,
      },
      new renodx::utils::settings::Setting{
          .key = "shadows",
          .binding = &shader_injection.shadows,
          .value_type = renodx::utils::settings::SettingValueType::FLOAT,
          .default_value = 1.00f,
          .label = "Shadows",
          .section = "Psycho V30",
          .min = 0.00f,
          .max = 2.00f,
          .format = "%.2f",
          .is_enabled = IsPsychoMode,
          .is_visible = IsPsychoMode,
      },
      new renodx::utils::settings::Setting{
          .key = "contrast",
          .binding = &shader_injection.contrast,
          .value_type = renodx::utils::settings::SettingValueType::FLOAT,
          .default_value = 1.00f,
          .label = "Contrast",
          .section = "Psycho V30",
          .min = 0.00f,
          .max = 2.00f,
          .format = "%.2f",
          .is_enabled = IsPsychoMode,
          .is_visible = IsPsychoMode,
      },
      new renodx::utils::settings::Setting{
          .key = "purity_scale",
          .binding = &shader_injection.saturation,
          .value_type = renodx::utils::settings::SettingValueType::FLOAT,
          .default_value = 1.00f,
          .label = "Saturation / Purity",
          .section = "Psycho V30",
          .min = 0.00f,
          .max = 2.00f,
          .format = "%.2f",
          .is_enabled = IsPsychoMode,
          .is_visible = IsPsychoMode,
      },
      new renodx::utils::settings::Setting{
          .key = "cone_response_exponent",
          .binding = &shader_injection.cone_response_exponent,
          .value_type = renodx::utils::settings::SettingValueType::FLOAT,
          .default_value = 1.00f,
          .label = "Cone Response Exponent",
          .section = "Psycho V30",
          .min = 0.00f,
          .max = 2.00f,
          .format = "%.2f",
          .is_enabled = IsPsychoMode,
          .is_visible = IsPsychoMode,
      },

      // User Grading (HDR Extended) //////////////////////////////////////////////////////////////
      new renodx::utils::settings::Setting{
          .key = "exposure_tpm",
          .binding = &shader_injection.exposure_tpm,
          .value_type = renodx::utils::settings::SettingValueType::FLOAT,
          .default_value = 1.0f,
          .label = "Exposure",
          .section = "User Grading",
          .min = 0.00f,
          .max = 2.00f,
          .format = "%.2f",
          .is_enabled = IsExtendedMode,
          .is_visible = IsExtendedMode,
      },
      new renodx::utils::settings::Setting{
          .key = "highlights_tpm",
          .binding = &shader_injection.highlights_tpm,
          .value_type = renodx::utils::settings::SettingValueType::FLOAT,
          .default_value = 1.00f,
          .label = "Highlights",
          .section = "User Grading",
          .min = 0.00f,
          .max = 2.00f,
          .format = "%.2f",
          .is_enabled = IsExtendedMode,
          .is_visible = IsExtendedMode,
      },
      new renodx::utils::settings::Setting{
          .key = "shadows_tpm",
          .binding = &shader_injection.shadows_tpm,
          .value_type = renodx::utils::settings::SettingValueType::FLOAT,
          .default_value = 1.0f,
          .label = "Shadows",
          .section = "User Grading",
          .min = 0.00f,
          .max = 2.00f,
          .format = "%.2f",
          .is_enabled = IsExtendedMode,
          .is_visible = IsExtendedMode,
      },
      new renodx::utils::settings::Setting{
          .key = "contrast_tpm",
          .binding = &shader_injection.contrast_tpm,
          .value_type = renodx::utils::settings::SettingValueType::FLOAT,
          .default_value = 1.0f,
          .label = "Contrast",
          .section = "User Grading",
          .min = 0.00f,
          .max = 2.00f,
          .format = "%.2f",
          .is_enabled = IsExtendedMode,
          .is_visible = IsExtendedMode,
      },
      new renodx::utils::settings::Setting{
          .key = "saturation_tpm",
          .binding = &shader_injection.saturation_tpm,
          .value_type = renodx::utils::settings::SettingValueType::FLOAT,
          .default_value = 1.0f,
          .label = "Saturation / Purity",
          .section = "User Grading",
          .min = 0.00f,
          .max = 2.00f,
          .format = "%.2f",
          .is_enabled = IsExtendedMode,
          .is_visible = IsExtendedMode,
      },

      // Extra //////////////////////////////////////////////////////////////////////////////////
      new renodx::utils::settings::Setting{
          .key = "bloom",
          .binding = &shader_injection.bloom,
          .default_value = 1.f,
          .label = "Bloom",
          .section = "Extra",
          .tooltip = "Bloom multiplier. Needs the in-game HDR setting on.",
          .min = 0.f,
          .max = 2.f,
          .format = "%.2f",
          .is_enabled = IsHDRMode,
          .is_visible = IsHDRMode,
      },
      new renodx::utils::settings::Setting{
          .key = "vignette",
          .binding = &shader_injection.vignette,
          .default_value = 1.f,
          .label = "Vignette",
          .section = "Extra",
          .tooltip = "Multiplier on vignette mask.",
          .min = 0.f,
          .max = 2.f,
          .format = "%.2f",
          .is_enabled = IsHDRMode,
          .is_visible = IsHDRMode,
      },
  };
}

bool configured = false;
bool attached = false;
bool addon_registered = false;

}  // namespace

// Lifecycle /////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void OnInitSwapchain(reshade::api::swapchain* swapchain, bool) {
  // The DX9 swap chain can't report the display's peak (only DXGI can): 1000 then.
  auto peak = renodx::utils::swapchain::GetPeakNits(swapchain);
  if (!peak.has_value()) {
    peak = 1000.f;
  }

  // find and set
  for (auto& setting : settings) {
    if (setting->binding != &shader_injection.peak_white_nits) continue;
    setting->default_value = peak.value();
    setting->max = std::max(peak.value(), setting->max);
    setting->can_reset = true;
    break;
  }
}

extern "C" __declspec(dllexport) constexpr const char* NAME = "RenoDX";
extern "C" __declspec(dllexport) constexpr const char* DESCRIPTION = "RenoDX - R.U.S.E. by ATN";

namespace {

void ConfigureAddon() {
  if (configured) return;

  // Construct the non-trivial containers here rather than during DLL loading.
  BuildRuntimeData();

  // Shaders: DX9 has no constant buffers, the injection goes into pixel shader
  // constants c200-c204 (shared.h). The game's shaders use the low registers.
  renodx::mods::shader::force_pipeline_cloning = true;
  renodx::mods::shader::expected_constant_buffer_space = 50;
  renodx::mods::shader::expected_constant_buffer_index = 13;
  renodx::mods::shader::constant_buffer_offset = 200 * 4;

  // Swapchain cb (the DX11 proxy)
  renodx::mods::swapchain::expected_constant_buffer_index = 13;
  renodx::mods::swapchain::expected_constant_buffer_space = 50;

  // DX9 presents through a DX11 HDR swap chain. The game renders into an FP16 copy of its
  // 8-bit back buffer, drawn to that swap chain with swap_chain_proxy_*.hlsl.
  renodx::mods::swapchain::use_device_proxy = true;
  renodx::mods::swapchain::use_resource_cloning = true;
  renodx::mods::swapchain::force_borderless = false;
  renodx::mods::swapchain::prevent_full_screen = true;
  renodx::mods::swapchain::swap_chain_proxy_vertex_shader = __swap_chain_proxy_vertex_shader_dx11;
  renodx::mods::swapchain::swap_chain_proxy_pixel_shader = __swap_chain_proxy_pixel_shader_dx11;

  // Resource Upgrades
  // The 10-bit scene (and bloom) targets: FP16 keeps the scene above 1.
  renodx::mods::swapchain::resource_upgrade_infos.push_back({
      .old_format = reshade::api::format::b10g10r10a2_unorm,
      .new_format = reshade::api::format::r16g16b16a16_float,
      .use_resource_view_cloning = true,
      .aspect_ratio = renodx::mods::swapchain::SwapChainUpgradeTarget::BACK_BUFFER,
      .aspect_ratio_tolerance = 0.01f,
      .usage_include = reshade::api::resource_usage::render_target,
  });

  // Appended Settings (HDR10)
  {
    auto* setting = new renodx::utils::settings::Setting{
        .key = "SwapChainEncoding",
        .value_type = renodx::utils::settings::SettingValueType::INTEGER,
        .default_value = 1.f,
        .label = "Output",
        .section = "Output (Restart Required)",
        .tooltip = "HDR10: 10bit, enough quality (banding?).\nscRGB: 16bit, overkill quality.",
        .labels = {"HDR10", "scRGB"},
        .is_global = true,
        .is_visible = IsAdvancedSettings,
    };
    renodx::utils::settings::LoadSetting(renodx::utils::settings::global_name, setting);
    const auto value = setting->GetValue();
    shader_injection.swap_chain_encoding = value;
    renodx::mods::swapchain::SetUseHDR10(value == 0);
    settings.push_back(setting);
  }

  // Appended Settings (About)
  settings.push_back(new renodx::utils::settings::Setting{
      .value_type = renodx::utils::settings::SettingValueType::TEXT,
      .label = "Turn on the in-game HDR setting.",
      .section = "About",
  });
  settings.push_back(new renodx::utils::settings::Setting{
      .value_type = renodx::utils::settings::SettingValueType::TEXT,
      .label = std::string("Build Date: ") + BUILD_DATE + " - " + BUILD_TIME,
      .section = "About",
      .is_visible = IsAdvancedSettings,
  });

  configured = true;
}

bool AttachAddon() {
  if (attached) return true;

  ConfigureAddon();

  reshade::register_event<reshade::addon_event::init_swapchain>(OnInitSwapchain);

  renodx::utils::settings::Use(DLL_PROCESS_ATTACH, &settings, nullptr);

  renodx::mods::swapchain::Use(DLL_PROCESS_ATTACH, &shader_injection);

  renodx::mods::shader::Use(DLL_PROCESS_ATTACH, custom_shaders, &shader_injection);

  attached = true;
  return true;
}

void DetachAddon() {
  if (!attached) return;

  reshade::unregister_event<reshade::addon_event::init_swapchain>(OnInitSwapchain);

  renodx::mods::shader::Use(DLL_PROCESS_DETACH, custom_shaders, &shader_injection);

  renodx::mods::swapchain::Use(DLL_PROCESS_DETACH, &shader_injection);

  renodx::utils::settings::Use(DLL_PROCESS_DETACH, &settings, nullptr);

  attached = false;
}

}  // namespace

extern "C" __declspec(dllexport) bool AddonInit(HMODULE addon_module, HMODULE) {
  if (!addon_registered) {
    if (!reshade::register_addon(addon_module)) return false;
    addon_registered = true;
  }

  return AttachAddon();
}

extern "C" __declspec(dllexport) void AddonUninit(HMODULE addon_module, HMODULE) {
  DetachAddon();
  if (addon_registered) {
    reshade::unregister_addon(addon_module);
    addon_registered = false;
  }
}

BOOL APIENTRY DllMain(HMODULE h_module, DWORD fdw_reason, LPVOID lpv_reserved) {
  switch (fdw_reason) {
    case DLL_PROCESS_ATTACH:
      if (!reshade::register_addon(h_module)) return FALSE;
      addon_registered = true;
      break;

    case DLL_PROCESS_DETACH:
      // ReShade calls AddonUninit before an explicit unload. During process
      // termination, avoid calling into ReShade or RenoDX under the loader lock.
      if (lpv_reserved == nullptr && addon_registered) {
        reshade::unregister_addon(h_module);
        addon_registered = false;
      }
      break;
  }

  return TRUE;
}
