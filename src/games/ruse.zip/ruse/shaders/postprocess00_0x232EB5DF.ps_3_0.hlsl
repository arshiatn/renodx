// R.U.S.E. final post process, in-game HDR on (10-bit scene + bloom). Writes the back buffer.
// Hand-decompiled from 0x232EB5DF.ps_3_0.cso (DX9), verified against it.
// Stock: directional blur + bloom -> x HDRParam.x -> desaturation, tint, dominant colour,
//        vignette -> luminance gamma, brightness. No tonemapper: the 8-bit back buffer clips at 1.
// HDR 0 (SDR): stock, then paper white.
// HDR 1 (Extended): no clip. Unchanged up to SDR white, then a shoulder into the peak.
// HDR 2 (PsychoV30): the unclipped image through PsychoV30.
// The 10-bit scene is FP16 now (addon.cpp), so it keeps values above 1.

#include "../shared.h"
#include "../psycho_test30.hlsli"

float4 PostProcess[11] : register(c0);           // one register per member:
#define NoiseLevel        PostProcess[0].x       // (unused here)
#define OverlayColor      PostProcess[1].xyz
#define MinVignettage     PostProcess[2].x
#define VignettageExtent  PostProcess[3].x
#define BloomFactor       PostProcess[4].x
#define Gamma             PostProcess[5].x
#define Brightness        PostProcess[6].x
#define SkyBrightness     PostProcess[7].x       // (unused here)
#define Desaturation      PostProcess[8].x
#define DominantColor     PostProcess[9].xyz
#define DominantColorProp PostProcess[10].x
float2 PrincipalMap_HDRParam : register(c11);

sampler2D PrincipalMap : register(s0);           // scene
sampler2D DownSizeMap : register(s1);            // bloom
sampler2D ShadowMap : register(s2);              // .yz: blur direction

static const float3 kLuma = float3(0.299f, 0.587f, 0.114f);
// Blur weights for +-1..8 steps (center 1). kBlurNormalize = 1 / (1 + 2 * sum).
static const float kBlurWeights[8] = {
  0.807401419f, 0.617947221f, 0.424969733f, 0.262608856f,
  0.145816088f, 0.0727522448f, 0.0326160975f, 0.0131390067f
};
static const float kBlurNormalize = 0.173777029f;

// Extended user grading (from Rome Remastered). Identity at defaults.
float3 ApplyExtendedUserGrading(float3 color)
{
  const float3 kLuminance = float3(0.212599993f, 0.715200007f, 0.0722000003f);
  const float mid_gray = 0.18f;

  float luminance = max(dot(color, kLuminance), 0.f);
  float graded_luminance = luminance * SI.exposure_tpm;
  graded_luminance = renodx::color::grade::Highlights(graded_luminance, SI.highlights_tpm, mid_gray);
  graded_luminance = renodx::color::grade::Shadows(graded_luminance, SI.shadows_tpm, mid_gray);

  if (SI.contrast_tpm != 1.f)
  {
    float normalized = max(graded_luminance / mid_gray, 0.f);
    graded_luminance = pow(normalized, SI.contrast_tpm) * mid_gray;
  }

  float tonal_scale = luminance > 0.000001f ? graded_luminance / luminance : 1.f;
  color *= tonal_scale;

  // Luma-preserving saturation. 1.0 is identity.
  float graded_y = dot(color, kLuminance);
  return lerp(graded_y.xxx, color, SI.saturation_tpm);
}

// Extended peak: rolls everything above 1.0 into the headroom. At or below 1.0 untouched.
float3 ApplyExtendedPeakShoulder(float3 color)
{
  float peak = max(HDR_PEAK, 1.0001f);
  float max_channel = max(color.r, max(color.g, color.b));

  if (max_channel > 1.f)
  {
    float headroom = peak - 1.f;
    float excess = max_channel - 1.f;
    float mapped_max = 1.f + renodx::tonemap::Neutwo(excess, headroom);
    color *= mapped_max / max_channel;
  }

  return color;
}

float4 main(float2 v0 : TEXCOORD0, float2 v1 : TEXCOORD1, float2 v2 : TEXCOORD2) : COLOR0
{
  // Threshold the float setting so a stray value cannot produce a hybrid mode.
  int hdr_mode = (HDR < 0.5f) ? 0 : ((HDR < 1.5f) ? 1 : 2);
  bool hdr = hdr_mode != 0;

  // The scene and bloom are FP16 now. SDR: clamp like the stock 10-bit textures.
  float tap_max = hdr ? 65504.f : 1.f;

  // 1. Directional blur. Step = (ShadowMap.y - 0.502, -(ShadowMap.z - 0.502)) + v2, x 0.01.
  float3 color = clamp(tex2Dlod(PrincipalMap, float4(v1, 0, 0)).rgb, 0.f, tap_max);
  float2 offset_map = tex2D(ShadowMap, v1).yz - 0.501960814f;
  float2 step_uv = (float2(offset_map.x, -offset_map.y) + v2) * 0.00999999978f;
  float4 step4 = float4(step_uv, -step_uv);
  float4 tap_uv = v1.xyxy + step4;  // stock steps the positions by adding
  [unroll]
  for (int i = 0; i < 8; ++i) {
    color += clamp(tex2Dlod(PrincipalMap, float4(tap_uv.xy, 0, 0)).rgb, 0.f, tap_max) * kBlurWeights[i];
    color += clamp(tex2Dlod(PrincipalMap, float4(tap_uv.zw, 0, 0)).rgb, 0.f, tap_max) * kBlurWeights[i];
    tap_uv += step4;
  }
  float3 bloom = clamp(tex2D(DownSizeMap, v1).rgb, 0.f, tap_max) * BloomFactor;
  if (hdr) bloom *= SI.bloom;  // Bloom slider (HDR only)
  color = color * kBlurNormalize + bloom;

  // 2. Scene range.
  color *= PrincipalMap_HDRParam.x;

  // 3. Grading.
  float lightness = 0.5f * (max(color.r, max(color.g, color.b)) + min(color.r, min(color.g, color.b)));
  color = lerp(color, lightness.xxx, Desaturation);
  color *= OverlayColor / dot(OverlayColor, kLuma);
  color = lerp(color, dot(color, 1.f) * DominantColor, DominantColorProp);

  float2 edge = min(1.f - v0, v0);  // distance to the nearest edges
  float t = saturate(sqrt(edge.x * edge.y) / VignettageExtent);
  float vignette = saturate((MinVignettage - 1.f) * t * t + (2.f - 2.f * MinVignettage) * t + MinVignettage);
  if (hdr) vignette = 1.f - saturate((1.f - vignette) * SI.vignette);  // Vignette slider (HDR only)
  color *= vignette;

  // 4. Luminance gamma and brightness. Black: stock makes NaN there (Gamma < 1), stored as 0.
  float luma = dot(color, kLuma);
  color = (luma > 0.f) ? color * pow(luma, Gamma - 1.f) : 0.f;
  color *= Brightness;

  if (!hdr) {
    // SDR: the 8-bit back buffer's clip, then paper white.
    color = renodx::color::gamma::DecodeSafe(saturate(color));
    color *= SI.diffuse_white_nits / SI.graphics_white_nits;
    return float4(renodx::color::gamma::EncodeSafe(color), 1.f);
  }

  // HDR: the back buffer holds gamma 2.2 values. Decode without the clip.
  color = renodx::color::gamma::DecodeSafe(color);
  [branch]
  if (hdr_mode == 1) {
    color = ApplyExtendedUserGrading(color);
    color = ApplyExtendedPeakShoulder(color);
  } else {
    color = ApplyPsychoV30(color);
  }

  color *= SI.diffuse_white_nits / SI.graphics_white_nits;
  return float4(renodx::color::gamma::EncodeSafe(color), 1.f);
}
