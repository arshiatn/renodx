// Planar video conversion, verified against the supplied CSO and assembly.
// Preserve the game's limited-range YUV coefficients, chroma UVs, tint and fades.
#include "../shared.h"

float4 YDimensions : register(c0);
float4 ChromaDimensions : register(c1);
sampler2D YTexture : register(s0);
sampler2D UTexture : register(s1);
sampler2D VTexture : register(s2);

struct PS_IN {
  float2 texcoord : TEXCOORD0;
  float4 color : COLOR0;
};

float4 main(PS_IN i) : COLOR0 {
  float4 r0;
  float4 r1;
  r0.xy = ChromaDimensions.zw + ChromaDimensions.zw;
  r1.x = 1.f / r0.x;
  r1.y = 1.f / r0.y;
  r0.xy = r1.xy * YDimensions.zw;
  r0.xy *= i.texcoord.xy;
  r1 = tex2D(VTexture, r0.xy);
  r0 = tex2D(UTexture, r0.xy);
  r0.x -= 0.5f;
  r0.xy = r0.xx * float2(0.391000003f, 2.01799989f);
  r0.z = r1.x - 0.5f;
  r1 = tex2D(YTexture, i.texcoord.xy);
  r0.w = r1.x - 0.0625f;
  r0.x = r0.w * 1.16400003f - r0.x;
  r1.z = r0.w * 1.16400003f + r0.y;
  r1.y = r0.z * -0.813000023f + r0.x;
  r0.x = r0.z * 1.59599996f;
  r1.x = r0.w * 1.16400003f + r0.x;
  r1.w = 1.f;
  half4 native_color = r1 * i.color;
  float4 color = native_color;

  if (SI.peak_white_nits > 0.f && SI.diffuse_white_nits > 0.f && SI.ui_draw > 0.5f) {
    // Restore the native UNORM clip before scaling, so video whites follow
    // Paper White without clipping them back to the 203-nit proxy reference.
    color = saturate(color);
    color.rgb *= SI.video_scale;
  }
  return color;
}
