# RenoDX — R.U.S.E.

Requires Windows HDR and the game's HDR option. Native scene targets keep
their packed 10-bit format. RenoDX uses an FP16 backbuffer clone and a DX11
HDR presentation proxy.

## Rendering modes

| Mode | Behaviour |
|---|---|
| SDR | Original scene response and clipped highlights, scaled by Paper White. |
| PsychoV30 - Native Tone | Former PsychoV30 mode. Applies PsychoV30 after the game's gamma/brightness response. |
| PsychoV30 - Full Replacement | Former PsychoV30 Direct. Replaces that gamma/brightness response with PsychoV30. Default. |

Both Psycho modes retain the game's colour grading, bloom, vignette and
directional blur. Their existing processing and shared Psycho controls are
unchanged. Extended and its separate grading controls have been removed.
Psycho controls, Bloom and Vignette appear only in Advanced settings with a
Psycho mode selected. Peak appears only in the Psycho modes.

The new `rendering_mode` config key avoids misreading old four-mode indices.
Upgrading resets the mode selection to Full Replacement; the other current
settings keep their existing keys. Recommended selects Full Replacement and
neutral Psycho controls. Reset Image Settings also resets Bloom and Vignette.
Both preserve Peak, Paper White, UI brightness and output settings.

## Brightness and cutscenes

Paper White scales the scene and cutscene video. UI brightness scales the
HUD/text separately. The video replacement is `0x1D8E1FA8`: its original
three-texture YUV-to-RGB conversion, UV scaling, vertex tint and fades are
preserved. Finished video keeps its original SDR contrast and colour; it does
not receive a Psycho tone curve.

Video is clipped to the native range before Paper White scaling. The final
proxy does not clip it back to the 203-nit reference. A white video pixel at
Paper White 400 therefore targets 400 nits, provided Peak is at least 400.
At Paper White 203 the gain is 1. UI brightness does not control video.

Only draws targeting the backbuffer receive UI/video scaling. Offscreen draws
and shaders without valid addon injection preserve their native output. UI
and video gains are captured once per host frame. If another video pass is
found, or this pass renders offscreen in a different cutscene, its final
composition pass still needs to be identified.

## Automatic loading-screen fix

The confirmed native DX9 ReShade GUI block is now automatic; there is no
compatibility slider. It prevents the stale startup banner and cursor trails
after successful HDR proxy presentation. The DX11 proxy overlay remains
available. Failed/occluded proxy frames and device recovery retain native
presentation and GUI. This retains the conditions of ATN's successful test.
The install log message is `R.U.S.E.: native DX9 GUI draw filter installed.`

## Highlight Hue Shift

Advanced → Psycho V30 → Highlight Hue Shift uses the supplied Claude source/
cone hue blend in both Psycho modes:

| Value | Fully weighted highlight direction |
|---|---|
| 0 | Source LMS/A2 hue. |
| 1 | Original PsychoV30 blend. Default. |
| 2 | Tonemapper's own per-cone response hue. |

Intermediate values blend these directions. The effect fades in above the
input adaptation anchor, preserving the opponent radius and C0 before the
existing gamut/Yf-ceiling projection. It affects all hues; gamut constraints
can also change brightness. The previously delivered output-anchor ramp
normalization for Full Replacement is retained.

## Build and verification

Replace the whole `src/games/ruse` folder and rebuild with the game closed.
Do not place dumped CSOs in that folder.

```powershell
cmake --preset clang-x64
cmake --build --preset clang-x64-debug --target ruse
```

Install `renodx-ruse.addon64`, keeping one R.U.S.E. addon in the game directory,
and restart. Check that `embed/0x1D8E1FA8.h` is generated and the video
replacement loads alongside the 13 existing replacements.

- Check loading before and after opening/closing the proxy overlay.
- During video, compare Paper White 100, 203 and 400 with Peak at least 400.
  Hold Paper White fixed and move UI brightness; only HUD/subtitles should change.
- Check video colour, black fades and transitions into gameplay.
- Compare both Psycho modes and hue values 0, 1 and 2. Check SDR and slider visibility.

The injection remains 24 floats (96 bytes), DX9 c200–c205. Former Extended
grading fields are padding; existing active offsets are retained. Offset 84
now holds the video gain. Rebuild shaders and addon together.

Local CPU/source checks cover video conversion and brightness, mode/default/
preset behaviour, all 14 draw callbacks, frame snapshots and the existing
GUI/Present/VSync recovery guards. Windows addon/FXC compilation and in-game
cutscene validation were not available here. ATN verified the loading fix in
the preceding build.
