cbuffer colorimetry_VS_PS : register(b0)
{
    float g_brightness        : packoffset(c0.x);
    float g_gamma_output      : packoffset(c0.y);
    float g_inv_gamma_output  : packoffset(c0.z);
};

cbuffer sprite_PS : register(b1)
{
    float g_windows_time_PS            : packoffset(c0.x);
    float g_model_time_PS              : packoffset(c0.y);
    float g_text_rendering_enabled_PS  : packoffset(c0.z);
    float g_switch_diffuse_channels   : packoffset(c0.w);

    float2 g_screen_dimensions_PS      : packoffset(c1.x);
    float2 g_campaign_shroud_uv_offset : packoffset(c1.z);
};

SamplerState s_diffuse_map_s               : register(s0);
SamplerState s_diffuse_map_point_sample_s  : register(s1);
SamplerState s_alt_map_s                   : register(s2);
SamplerState s_campaign_shroud_map_s       : register(s3);

Texture2D<float4> s_diffuse_map             : register(t0);
Texture2D<float4> s_diffuse_map_point_sample: register(t1);
Texture2D<float4> s_alt_map                 : register(t2);
Texture2D<float4> s_campaign_shroud_map     : register(t3);

// 3Dmigoto comparison macro.
#define cmp -
#include "../shared.h"

void main(  
    float4 v0 : SV_Position0,
    float4 v1 : COLOR0,
    float2 v2 : TEXCOORD0,
    float2 w2 : TEXCOORD1,
    float4 v3 : TEXCOORD3,
    float4 v4 : TEXCOORD4,
    float2 v5 : TEXCOORD5,
    float  w5 : TEXCOORD7,
    float4 v6 : TEXCOORD6,
    float2 v7 : TEXCOORD8,
    out float4 o0 : SV_Target0)
{
    float4 r0, r1, r2, r3, r4, r5, r6;
    float customGamma = 1 / 2.2f;
    
    // getting rid of the game Setting's gamma on the color v1
    v1.xyz = renodx::color::gamma::EncodeSafe(v1.xyz, g_gamma_output);
    v1.xyz = renodx::color::gamma::DecodeSafe(v1.xyz);

    // -------------------------------------------------------------------------
    // 0-3
    // -------------------------------------------------------------------------

    // DXBC:
    // mov r0.yw, v2.wwww
    //
    // v2.w == w2.y, and the source is replicated.
    r0.yw = w2.yy;

    r1.xyzw = v2.xyxy +
              float4(-0.000500000024,
                     -0.000500000024,
                      0.0,
                     -0.000500000024);

    r2.xyzw = s_diffuse_map_point_sample.SampleLevel(
        s_diffuse_map_point_sample_s,
        r1.xy,
        r1.y);

    r1.xyzw = s_diffuse_map_point_sample.SampleLevel(
        s_diffuse_map_point_sample_s,
        r1.zw,
        r1.w);

    // -------------------------------------------------------------------------
    // 4-18
    // -------------------------------------------------------------------------

    r1.x = -v3.z + v3.w;

    r0.x = r2.w * r1.x + v3.z;

    r2.xyzw = s_alt_map.SampleLevel(
        s_alt_map_s,
        r0.xy,
        w2.y);

    // DXBC: mov r3.yw, v2.wwww
    r3.yw = w2.yy;

    r4.xyzw = s_diffuse_map_point_sample.SampleLevel(
        s_diffuse_map_point_sample_s,
        v2.xy,
        v2.y);

    r3.x = r4.w * r1.x + v3.z;

    r4.xyzw = s_alt_map.SampleLevel(
        s_alt_map_s,
        r3.xy,
        w2.y);

    r0.x = cmp(0.5 < g_switch_diffuse_channels);

    r2.xz = r0.xx ? r2.zx : r2.xz;
    r4.xz = r0.xx ? r4.zx : r4.xz;

    r2.xyzw = r2.xyzw + r4.xyzw;

    r0.z = r1.w * r1.x + v3.z;

    r4.xyzw = s_alt_map.SampleLevel(
        s_alt_map_s,
        r0.zw,
        w2.y);

    r4.xz = r0.xx ? r4.zx : r4.xz;

    r2.xyzw = r2.xyzw + r4.xyzw;

    // -------------------------------------------------------------------------
    // 19-30
    // -------------------------------------------------------------------------

    // DXBC: mov r4.yw, v2.wwww
    r4.yw = w2.yy;

    r5.xyzw = v2.xyxy +
              float4( 0.000500000024,
                     -0.000500000024,
                     -0.000500000024,
                      0.0);

    r6.xyzw = s_diffuse_map_point_sample.SampleLevel(
        s_diffuse_map_point_sample_s,
        r5.xy,
        r5.y);

    r5.xyzw = s_diffuse_map_point_sample.SampleLevel(
        s_diffuse_map_point_sample_s,
        r5.zw,
        r5.w);

    r4.z = r5.w * r1.x + v3.z;

    r5.xyzw = s_alt_map.SampleLevel(
        s_alt_map_s,
        r4.zw,
        w2.y);

    r4.x = r6.w * r1.x + v3.z;

    r4.xyzw = s_alt_map.SampleLevel(
        s_alt_map_s,
        r4.xy,
        w2.y);

    r4.xz = r0.xx ? r4.zx : r4.xz;

    r2.xyzw = r2.xyzw + r4.xyzw;

    r5.xz = r0.xx ? r5.zx : r5.xz;

    r2.xyzw = r2.xyzw + r5.xyzw;

    // -------------------------------------------------------------------------
    // 31-42
    // -------------------------------------------------------------------------

    r4.xyzw = v2.xyxy +
              float4( 0.000500000024,
                      0.0,
                     -0.000500000024,
                      0.000500000024);

    r5.xyzw = s_diffuse_map_point_sample.SampleLevel(
        s_diffuse_map_point_sample_s,
        r4.xy,
        r4.y);

    r4.xyzw = s_diffuse_map_point_sample.SampleLevel(
        s_diffuse_map_point_sample_s,
        r4.zw,
        r4.w);

    r4.x = r4.w * r1.x + v3.z;

    r3.z = r5.w * r1.x + v3.z;

    r3.xyzw = s_alt_map.SampleLevel(
        s_alt_map_s,
        r3.zw,
        w2.y);

    r3.xz = r0.xx ? r3.zx : r3.xz;

    r2.xyzw = r2.xyzw + r3.xyzw;

    // DXBC: mov r4.yw, v2.wwww
    r4.yw = w2.yy;

    r3.xyzw = s_alt_map.SampleLevel(
        s_alt_map_s,
        r4.xy,
        w2.y);

    r3.xz = r0.xx ? r3.zx : r3.xz;

    r2.xyzw = r2.xyzw + r3.xyzw;

    // -------------------------------------------------------------------------
    // 43-55
    // -------------------------------------------------------------------------

    r3.xyzw = v2.xyxy +
              float4(0.0,
                     0.000500000024,
                     0.000500000024,
                     0.000500000024);

    r5.xyzw = s_diffuse_map_point_sample.SampleLevel(
        s_diffuse_map_point_sample_s,
        r3.xy,
        r3.y);

    r3.xyzw = s_diffuse_map_point_sample.SampleLevel(
        s_diffuse_map_point_sample_s,
        r3.zw,
        r3.w);

    r3.x = r3.w * r1.x + v3.z;

    r4.z = r5.w * r1.x + v3.z;

    r1.xyzw = s_alt_map.SampleLevel(
        s_alt_map_s,
        r4.zw,
        w2.y);

    r1.xz = r0.xx ? r1.zx : r1.xz;

    r1.xyzw = r2.xyzw + r1.xyzw;

    r3.y = w2.y;

    r2.xyzw = s_alt_map.SampleLevel(
        s_alt_map_s,
        r3.xy,
        w2.y);

    r2.xz = r0.xx ? r2.zx : r2.xz;

    r1.xyzw = r1.xyzw + r2.xyzw;

    // 9-tap average.
    r1.xyzw = r1.xyzw * 0.111111112;

    // -------------------------------------------------------------------------
    // 56-67
    // -------------------------------------------------------------------------

    r0.y = v2.y * 0.200000003 + w2.x;

    // Important:
    //
    // DXBC:
    // mul r0.yz, r0.yyyy, l(0, 500, 1000, 0)
    //
    // Because the destination is .yz, the immediate's y/z components are
    // selected. Thus this is:
    //
    // r0.y = r0.y * 500
    // r0.z = r0.y * 1000
    //
    // The original decompiler output is correct here.
    r0.yz = r0.yy * float2(500.0, 1000.0);

    r0.z = cmp(r0.z >= -r0.z);

    r0.zw = r0.zz
        ? float2(2.000000, 0.500000)
        : float2(-2.000000, -0.500000);

    r0.y = r0.y * r0.w;

    r0.y = frac(r0.y);

    r0.y = r0.z * r0.y;

    r0.y = cmp(1.0 < r0.y);

    // DXBC:
    // eq r0.zw, v3.xxxy, l(0,0,1,1)
    //
    // With destination mask .zw:
    //   destination z uses source v3.x and constant 1
    //   destination w uses source v3.y and constant 1
    //
    // Therefore the decompiler's v3.xy comparison is correct.
    r0.zw = cmp(v3.xy == float2(1.0, 1.0));

    r0.y = cmp((int)r0.w == (int)r0.y);

    r0.y = r0.y ? 0.0 : r1.w;

    r0.y = r0.z ? r0.y : r1.w;

    // -------------------------------------------------------------------------
    // 68-75: colour + alpha
    // -------------------------------------------------------------------------

    r1.xyz = saturate(r1.xyz);

    // UI-SLIDER
    r1.xyz *= SI.graphics_white_nits / 80.f;

    r1.xyz = log2(r1.xyz);
    r1.xyz = customGamma * r1.xyz;
    o0.xyz = exp2(r1.xyz);

    r1.xyzw = s_diffuse_map.SampleLevel(
        s_diffuse_map_s,
        v2.xy,
        v2.y);

    r0.x = r0.x ? r1.z : r1.x;

    r0.x = r0.x * v1.w;

    r0.x = r0.y * r0.x;

    // -------------------------------------------------------------------------
    // 76-79: campaign shroud UV
    // -------------------------------------------------------------------------

    // DXBC:
    // mad r0.yz, -cb1[1].zzwz, l(0,2,2,0), l(0,1,1,0)
    //
    // Destination yz selects:
    //   y -> cb1[1].z = offset.x
    //   z -> cb1[1].w = offset.y
    //
    // Therefore the decompiler's vector expression is correct.
    r0.yz = -g_campaign_shroud_uv_offset.xy * float2(2.0, 2.0)
           + float2(1.0, 1.0);

    // DXBC:
    // mad r1.yz, v7.xxyx, r0.yyzy, cb1[1].zzwz
    //
    // Destination yz selects:
    //   v7.xxyx -> (v7.x, v7.y)
    //   r0.yyzy -> (r0.y, r0.z)
    //   cb1.zzwz -> (offset.x, offset.y)
    //
    // Thus the decompiler's expression is also correct.
    r1.yz = v7.xy * r0.yz
          + g_campaign_shroud_uv_offset.xy;

    r1.xw = float2(1.0, 1.0) - r1.zz;

    r1.xyzw = s_campaign_shroud_map.SampleLevel(
        s_campaign_shroud_map_s,
        r1.yw,
        r1.x);

    // -------------------------------------------------------------------------
    // 80-90
    // -------------------------------------------------------------------------

    r0.y = r1.w - 0.5;

    r0.yz = r0.yy * float2(1.5, 1.5)
           + float2(0.5, 0.199999988);

    r0.w = r0.z * 5.26315784;

    r1.xy = cmp(r0.yz < float2(0.300000012,
                               0.0380000025));

    r0.y = cmp(0.49000001 < r0.y);

    r0.z = r1.y ? 0.200000003 : r0.w;

    r0.y = r0.y ? 1.0 : r0.z;

    r0.y = r1.x ? 0.0 : r0.y;

    r0.z = r0.x * r0.y - 0.00392156886;

    r0.x = r0.x * r0.y;

    o0.w = r0.x;

    // -------------------------------------------------------------------------
    // 91-99: discard tests
    // -------------------------------------------------------------------------

    r0.x = cmp(r0.z < 0.0);

    if (r0.x != 0.0)
        discard;

    r0.xy = v5.xy - v4.xw;

    r0.zw = v4.zy - v5.xy;

    r0.xyzw = cmp(r0.xyzw < float4(0.0, 0.0, 0.0, 0.0));

    r0.xy = (int2)r0.zw | (int2)r0.xy;

    r0.x = (int)r0.y | (int)r0.x;

    if (r0.x != 0.0)
        discard;

    return;
}