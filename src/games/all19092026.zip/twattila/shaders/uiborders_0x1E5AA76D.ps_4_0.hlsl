// ---- Created with 3Dmigoto v1.3.16 on Sun Aug 30 12:31:42 2026

cbuffer colorimetry_VS_PS : register(b0)
{
  float g_brightness : packoffset(c0);
  float g_gamma_output : packoffset(c0.y);
  float g_inv_gamma_output : packoffset(c0.z);
}

cbuffer camera_VS_PS : register(b1)
{
  float3 camera_position : packoffset(c0);
  float4x4 view : packoffset(c1);
  float4x4 projection : packoffset(c5);
  float4x4 view_projection : packoffset(c9);
  float4x4 inv_view : packoffset(c13);
  float4x4 inv_projection : packoffset(c17);
  float4x4 inv_view_projection : packoffset(c21);
  float4 camera_near_far : packoffset(c25);
  float time_in_sec : packoffset(c26);
  float2 g_inverse_focal_length : packoffset(c26.y);
  float g_vertical_fov : packoffset(c26.w);
  float4 g_screen_size : packoffset(c27);
  float g_vpos_texel_offset : packoffset(c28);
  float4 g_viewport_dimensions : packoffset(c29);
  float4 g_render_target_dimensions : packoffset(c30);
  float4 g_camera_temp0 : packoffset(c31);
  float4 g_camera_temp1 : packoffset(c32);
  float4 g_camera_temp2 : packoffset(c33);
  float4 g_clip_rect : packoffset(c34);
  int g_num_of_samples : packoffset(c35);
}

cbuffer lighting_VS_PS : register(b2)
{
  bool g_apply_environment_specular : packoffset(c0);
  float3 sun_direction : packoffset(c0.y);
  float3 sun_colour : packoffset(c1);
  float3 ambient_cube_lr[2] : packoffset(c2);
  float3 ambient_cube_tb[2] : packoffset(c4);
  float3 ambient_cube_fb[2] : packoffset(c6);
  float3 g_deep_water_colour : packoffset(c8);
  float3 g_shallow_water_colour : packoffset(c9);
  float3 g_sea_bed_light_scatter : packoffset(c10);
  float g_refraction_light_scatter : packoffset(c10.w);
  float g_hdr_on : packoffset(c11);
  bool g_ssr_enabled : packoffset(c11.y);
}

cbuffer shroud_PS : register(b3)
{
  float g_shroud_enabled : packoffset(c0);
  float g_campaign_autumn_timer : packoffset(c0.y);
  float4 g_campaign_world_bounds : packoffset(c1);
  float4 g_campaign_playable_area_bounds : packoffset(c2);
  float g_snow_height : packoffset(c3) = {1.39999998};
  float g_rock_slope_scale : packoffset(c3.y) = {0.400000006};
  float g_rock_height_min : packoffset(c3.z) = {0.400000006};
  float g_rock_height_max : packoffset(c3.w) = {1.39999998};
  float2 g_uv_offset : packoffset(c4);
}

cbuffer campaign_border_PS : register(b4)
{
  float4x4 g_bezier_basis : packoffset(c0);
  float4 g_border_colour_a : packoffset(c4);
  float g_length : packoffset(c5);
  float g_start_length : packoffset(c5.y);
  float g_end_length : packoffset(c5.z);
}

SamplerState s_shroud_s : register(s0);
SamplerState s_border_diffuse_s : register(s1);
Texture2D<float4> s_border_diffuse : register(t0);
Texture2D<float4> s_shroud : register(t1);


// 3Dmigoto declarations
#define cmp -
#include "../shared.h"


void main(
  float4 v0 : SV_Position0,
  float4 v1 : TEXCOORD0,
  float4 v2 : TEXCOORD1,
  float4 v3 : TEXCOORD2,
  out float4 o0 : SV_Target0)
{
  float4 r0,r1,r2,r3,r4;
  uint4 bitmask, uiDest;
  float4 fDest;
  float customGamma = 1 / 2.2f;

  r0.x = max(0, -sun_direction.y);
  r1.xyzw = s_border_diffuse.Sample(s_border_diffuse_s, v2.xy).xyzw;
  r0.yzw = saturate(g_border_colour_a.xyz);
  r0.yzw = saturate(r0.yzw * r1.xyz);

  r0.yzw = log2(r0.yzw);
  r0.yzw = customGamma * r0.yzw;
  r0.yzw = exp2(r0.yzw);

  r1.x = cmp(0.5 < g_shroud_enabled);
  if (r1.x != 0) {
    r2.xyzw = -g_campaign_world_bounds.xyxy + v1.xzxz;
    r3.xyzw = g_campaign_world_bounds.zwzw + -g_campaign_world_bounds.xyxy;
    r2.xyzw = r2.xyzw / r3.xyzw;
    r3.xyzw = -g_uv_offset.xyxy * float4(2,2,2,2) + float4(1,1,1,1);
    r2.xyzw = r2.xyzw * r3.xyzw + g_uv_offset.xyxy;
    r3.xyzw = s_shroud.SampleLevel(s_shroud_s, r2.zw, r2.w).xyzw;
    r2.xyzw = float4(0.00999999978,0.00999999978,-1,-1) + r2.xyzw;
    r2.xyzw = saturate(float4(100,100,100.000099,100.000099) * r2.xyzw);
    r4.xyzw = r2.xyzw * float4(-2,-2,-2,-2) + float4(3,3,3,3);
    r2.xyzw = r2.xyzw * r2.xyzw;
    r2.xyzw = r4.xyzw * r2.xyzw;
    r1.y = r2.x * r3.w;
    r1.y = r2.y * r1.y;
    r1.y = r2.z * -r1.y + r1.y;
    r1.y = r2.w * -r1.y + r1.y;
    r1.y = saturate(-0.5 + r1.y);
    r1.y = r1.y + r1.y;
  } else {
    r1.y = 1;
  }
  r1.z = 1 + -r1.y;
  r1.y = r1.z * 0.25 + r1.y;
  r1.y = r1.w * r1.y;
  r1.z = cmp(0 < g_length);
  r1.w = g_length * v2.x;
  r1.w = saturate(r1.w / g_start_length);
  r2.x = 1 + -v2.x;
  r2.x = g_length * r2.x;
  r2.x = saturate(r2.x / g_end_length);
  r1.w = r2.x * r1.w;
  r1.w = r1.y * r1.w;
  r1.y = r1.z ? r1.w : r1.y;
  r1.zw = -camera_position.xz + v1.xz;
  r1.z = dot(r1.zw, r1.zw);
  r1.z = sqrt(r1.z);
  r1.z = 0.0105263162 * r1.z;
  r1.z = min(1, r1.z);
  r1.z = 1 + -r1.z;
  r0.xyz = r0.yzw * r0.xxx;
  r0.xyz = sun_colour.xyz * r0.xyz;
  r0.w = cmp(0 < g_hdr_on);
  r0.w = r0.w ? 0.00400000019 : 1;
  o0.xyz = r0.xyz * r0.www;
  if (r1.x != 0) {
    r0.xyzw = -g_campaign_world_bounds.xyxy + v1.xzxz;
    r2.xyzw = g_campaign_world_bounds.zwzw + -g_campaign_world_bounds.xyxy;
    r0.xyzw = r0.xyzw / r2.xyzw;
    r2.xyzw = -g_uv_offset.xyxy * float4(2,2,2,2) + float4(1,1,1,1);
    r0.xyzw = r0.xyzw * r2.xyzw + g_uv_offset.xyxy;
    r2.xyzw = s_shroud.SampleLevel(s_shroud_s, r0.zw, r0.w).xyzw;
    r0.xyzw = float4(0.00999999978,0.00999999978,-1,-1) + r0.xyzw;
    r0.xyzw = saturate(float4(100,100,100.000099,100.000099) * r0.xyzw);
    r3.xyzw = r0.xyzw * float4(-2,-2,-2,-2) + float4(3,3,3,3);
    r0.xyzw = r0.xyzw * r0.xyzw;
    r0.xyzw = r3.xyzw * r0.xyzw;
    r0.x = r0.x * r2.w;
    r0.x = r0.y * r0.x;
    r0.x = r0.z * -r0.x + r0.x;
    r0.x = r0.w * -r0.x + r0.x;
  } else {
    r0.x = 1;
  }
  r0.x = -0.25 + r0.x;
  r0.x = saturate(4 * r0.x);
  r0.x = r1.y * r0.x;
  r0.x = g_border_colour_a.w * r0.x;
  o0.w = r0.x * r1.z;
  return;
}