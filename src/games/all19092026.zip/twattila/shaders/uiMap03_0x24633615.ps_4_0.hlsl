// ---- Created with 3Dmigoto v1.3.16 on Sun Aug 30 13:20:58 2026

cbuffer colorimetry_VS_PS : register(b0)
{
  float g_brightness : packoffset(c0);
  float g_gamma_output : packoffset(c0.y);
  float g_inv_gamma_output : packoffset(c0.z);
}

cbuffer sprite_PS : register(b1)
{
  float g_windows_time_PS : packoffset(c0);
  float g_model_time_PS : packoffset(c0.y);
  float g_text_rendering_enabled_PS : packoffset(c0.z);
  float g_switch_diffuse_channels : packoffset(c0.w);
  float2 g_screen_dimensions_PS : packoffset(c1);
  float2 g_campaign_shroud_uv_offset : packoffset(c1.z);
}

SamplerState s_diffuse_map_s : register(s0);
SamplerState s_campaign_shroud_map_s : register(s1);
Texture2D<float4> s_diffuse_map : register(t0);
Texture2D<float4> s_campaign_shroud_map : register(t1);


// 3Dmigoto declarations
#define cmp -
#include "../shared.h"

void main(
  float4 v0 : SV_Position0,
  float4 v1 : COLOR0,
  float2 v2 : TEXCOORD0,
  float2 w2 : TEXCOORD1,
  float4 v3 : TEXCOORD2,
  float4 v4 : TEXCOORD3,
  float4 v5 : TEXCOORD4,
  float2 v6 : TEXCOORD5,
  float w6 : TEXCOORD6,
  out float4 o0 : SV_Target0)
{
  float4 r0,r1,r2;
  uint4 bitmask, uiDest;
  float4 fDest;
  float customGamma = 1 / 2.2f;

  // getting rid of the game Setting's gamma on the color v1
  v1.xyz = renodx::color::gamma::EncodeSafe(v1.xyz, g_gamma_output);
  v1.xyz = renodx::color::gamma::DecodeSafe(v1.xyz);

  r0.xy = v6.xy + -v5.xw;
  r0.zw = -v6.xy + v5.zy;
  r0.xyzw = cmp(r0.xyzw < float4(0,0,0,0));
  r0.xy = (int2)r0.zw | (int2)r0.xy;
  r0.x = (int)r0.y | (int)r0.x;
  if (r0.x != 0) discard;
  r0.xy = -g_campaign_shroud_uv_offset.xy * float2(2,2) + float2(1,1);
  r0.yz = w2.xy * r0.xy + g_campaign_shroud_uv_offset.xy;
  r0.xw = float2(1,1) + -r0.zz;
  r0.xyzw = s_campaign_shroud_map.SampleLevel(s_campaign_shroud_map_s, r0.yw, r0.x).xyzw;
  r0.x = -0.5 + r0.w;
  r0.xy = r0.xx * float2(1.5,1.5) + float2(0.5,0.199999988);
  r0.z = 5.26315784 * r0.y;
  r0.yw = cmp(r0.xy < float2(0.300000012,0.0380000025));
  r0.x = cmp(0.49000001 < r0.x);
  r0.z = r0.w ? 0.200000003 : r0.z;
  r0.x = r0.x ? 1 : r0.z;
  r0.x = r0.y ? 0.200000003 : r0.x;
  r1.xyzw = s_diffuse_map.SampleLevel(s_diffuse_map_s, v2.xy, v2.y).xyzw;
  r0.y = saturate(r1.x);
  r0.y = log2(r0.y);
  r0.y = customGamma * r0.y;
  r2.w = exp2(r0.y);
  r2.xyz = float3(1,1,1);
  r0.yz = cmp(float2(0.5,0.5) < g_text_rendering_enabled_PS);
  r1.xz = r0.zz ? r1.zx : r1.xz;
  r1.xyzw = r0.yyyy ? r2.xyzw : r1.xyzw;
  r1.xyzw = v1.xyzw * r1.xyzw;
  r0.y = r1.w * r0.x + -0.00392156886;
  r0.x = r1.w * r0.x;
  r1.xyz = saturate(r1.xyz);

  // UI-SLIDER

  r1.xyz = log2(r1.xyz);
  r1.xyz = customGamma * r1.xyz;
  o0.xyz = exp2(r1.xyz);
  o0.w = r0.x;
  r0.x = cmp(r0.y < 0);
  if (r0.x != 0) discard;

  o0.xyz = renodx::color::gamma::DecodeSafe(o0.xyz);
  o0.xyz *= SI.graphics_white_nits / 80.f;
  o0.xyz = renodx::color::gamma::EncodeSafe(o0.xyz);
  return;
}