// ---- Created with 3Dmigoto v1.3.16 on Tue Sep 01 18:22:58 2026

// 3Dmigoto declarations
#define cmp -
#include "../shared.h"


void main(
  float4 v0 : SV_Position0,
  float4 v1 : COLOR0,
  float2 v2 : TEXCOORD0,
  float w2 : TEXCOORD7,
  float4 v3 : TEXCOORD1,
  float4 v4 : TEXCOORD2,
  float3 v5 : TEXCOORD3,
  out float4 o0 : SV_Target0)
{
  float4 r0,r1;
  uint4 bitmask, uiDest;
  float4 fDest;
  float customGamma = 1 / 2.2f;
  float game_brightness = SI.diffuse_white_nits;

  // getting rid of the game Setting's gamma on the color v1
  v1.xyz = renodx::color::gamma::EncodeSafe(v1.xyz, 1 / 0.5f);
  v1.xyz = renodx::color::gamma::DecodeSafe(v1.xyz);

  r0.xy = cmp(v5.xy >= v4.xw);
  r0.zw = cmp(v4.zy >= v5.xy);
  r0.x = r0.z ? r0.x : 0;
  r0.x = r0.w ? r0.x : 0;
  r0.x = r0.y ? r0.x : 0;
  if (r0.x != 0) {
    r0.xy = float2(0.5,0.5) + v2.xy;
    r0.xy = float2(2.5,2.5) * abs(r0.xy);
    r0.xy = frac(r0.xy);
    r0.xy = cmp(r0.xy >= float2(0.5,0.5));
    r1.xyz = r0.yyy ? float3(0.5,0.5,0.589999974) : float3(0.800000012,0.850000024,0.899999976);
    r0.yzw = r0.yyy ? float3(0.800000012,0.850000024,0.899999976) : float3(0.5,0.5,0.589999974);
    r0.xyz = r0.xxx ? r1.xyz : r0.yzw;
    r1.xyz = v1.xyz + -r0.xyz;
    r0.xyz = saturate(v1.www * r1.xyz + r0.xyz);
    r0.xyz = log2(r0.xyz);
    r0.xyz = customGamma * r0.xyz;
    r0.xyz = exp2(r0.xyz);
    r0.w = 1;
  } else {
    if (-1 != 0) discard;
  }
  r1.x = -0.00392156886 + r0.w;
  r1.x = cmp(r1.x < 0);
  if (r1.x != 0) discard;
  o0.xyzw = r0.xyzw;

  // USING GAME BRIGHTNESS
  if (r0.x != 0) o0.xyz = renodx::color::gamma::DecodeSafe(o0.xyz); //correct?

  o0.xyz *= game_brightness / 80.f;
  o0.xyz = renodx::color::gamma::EncodeSafe(o0.xyz);
  return;
}