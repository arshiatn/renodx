// name of cities

cbuffer colorimetry_VS_PS : register(b0)
{
  float g_brightness : packoffset(c0);
  float g_gamma_output : packoffset(c0.y);
  float g_inv_gamma_output : packoffset(c0.z);
}

cbuffer sprite_PS : register(b1)
{
  float g_windows_time_PS : packoffset(c0);
  float g_model_time_PS : packoffset(c0.y);
  float g_text_rendering_enabled_PS : packoffset(c0.z);
  float g_switch_diffuse_channels : packoffset(c0.w);
  float2 g_screen_dimensions_PS : packoffset(c1);
  float2 g_campaign_shroud_uv_offset : packoffset(c1.z);
}

SamplerState s_diffuse_map_s : register(s0);
Texture2D<float4> s_diffuse_map : register(t0);


// 3Dmigoto declarations
#define cmp -
#include "../shared.h"

void main(
  float4 v0 : SV_Position0,
  float4 v1 : COLOR0,
  float2 v2 : TEXCOORD0,
  float2 w2 : TEXCOORD1,
  float4 v3 : TEXCOORD2,
  float4 v4 : TEXCOORD3,
  float4 v5 : TEXCOORD4,
  float2 v6 : TEXCOORD5,
  float w6 : TEXCOORD6,
  out float4 o0 : SV_Target0)
{
  float4 r0,r1,r2,r3,r4,r5;
  uint4 bitmask, uiDest;
  float4 fDest;
  float customgamma = 1 / 2.2f;
  float ui_brightness = SI.graphics_white_nits;

  // getting rid of the game Setting's gamma on the color v1
  v1.xyz = renodx::color::gamma::EncodeSafe(v1.xyz, g_gamma_output);
  v1.xyz = renodx::color::gamma::DecodeSafe(v1.xyz);
  
  float4 x0[2];
  r0.xyzw = s_diffuse_map.SampleLevel(s_diffuse_map_s, v2.xy, v2.y).xyzw;
  r1.x = saturate(r0.x);
  r1.x = log2(r1.x);
  r1.x = customgamma * r1.x;
  r1.w = exp2(r1.x);

  r2.xy = cmp(float2(0.5,0.5) < g_text_rendering_enabled_PS);
  r0.xz = r2.yy ? r0.zx : r0.xz;
  r1.xyz = float3(1,1,1);
  r3.xyzw = r2.xxxx ? r1.xyzw : r0.xyzw;
  r4.xyzw = v1.xyzw * r3.xyzw;
  r0.xy = cmp(float2(0.0799999982,0.0199999996) < w2.xy);
  r0.x = r0.y ? r0.x : 0;
  if (r0.x != 0) {
    r0.x = r2.x ? r1.w : r0.w;
    r0.zw = cmp(v4.xy != float2(0,0));
    if (r0.z != 0) {
      r1.x = v4.x * -0.00100000005 + v2.x;
      r1.y = v2.y;
      r5.xyzw = s_diffuse_map.SampleLevel(s_diffuse_map_s, r1.xy, v2.y).xyzw;
      r5.x = saturate(r5.x);
      r0.z = log2(r5.x);
      r0.z = customgamma * r0.z;
      r0.z = exp2(r0.z);
      r0.z = r2.x ? r0.z : r5.w;
      r1.y = 1 + -r0.x;
      r0.z = r0.z * r1.y + r0.x;
      r2.yz = float2(-0.00100000005,0.00100000005) + v2.yy;
      r1.zw = float2(-0.00100000005,0.00100000005) + v2.yy;
      r5.xyzw = s_diffuse_map.SampleLevel(s_diffuse_map_s, r1.xz, r2.y).xyzw;
      r5.x = saturate(r5.x);
      r1.y = log2(r5.x);
      r1.y = customgamma * r1.y;
      r1.y = exp2(r1.y);
      r1.y = r2.x ? r1.y : r5.w;
      r1.z = 1 + -r0.z;
      r0.z = r1.y * r1.z + r0.z;
      r1.xyzw = s_diffuse_map.SampleLevel(s_diffuse_map_s, r1.xw, r2.z).xyzw;
      r1.x = saturate(r1.x);
      r1.x = log2(r1.x);
      r1.x = customgamma * r1.x;
      r1.x = exp2(r1.x);
      r1.x = r2.x ? r1.x : r1.w;
      r1.y = 1 + -r0.z;
      r0.x = r1.x * r1.y + r0.z;
    }
    if (r0.w != 0) {
      r1.x = v4.y * -0.00100000005 + v2.y;
      r1.y = v2.x;
      r5.xyzw = s_diffuse_map.SampleLevel(s_diffuse_map_s, r1.yx, r1.x).xyzw;
      r5.x = saturate(r5.x);
      r0.z = log2(r5.x);
      r0.z = customgamma * r0.z;
      r0.z = exp2(r0.z);
      r0.z = r2.x ? r0.z : r5.w;
      r0.w = 1 + -r0.x;
      r0.z = r0.z * r0.w + r0.x;
      r1.zw = float2(-0.00100000005,0.00100000005) + v2.xx;
      r5.xyzw = s_diffuse_map.SampleLevel(s_diffuse_map_s, r1.zx, r1.x).xyzw;
      r5.x = saturate(r5.x);
      r0.w = log2(r5.x);
      r0.w = customgamma * r0.w;
      r0.w = exp2(r0.w);
      r0.w = r2.x ? r0.w : r5.w;
      r1.y = 1 + -r0.z;
      r0.z = r0.w * r1.y + r0.z;
      r1.xyzw = s_diffuse_map.SampleLevel(s_diffuse_map_s, r1.wx, r1.x).xyzw;
      r1.x = saturate(r1.x);
      r0.w = log2(r1.x);
      r0.w = customgamma * r0.w;
      r0.w = exp2(r0.w);
      r0.w = r2.x ? r0.w : r1.w;
      r1.x = 1 + -r0.z;
      r0.x = r0.w * r1.x + r0.z;
    }
    x0[0].xyz = float3(0,0,0);
    x0[1].xyz = float3(1,1,1);
    r0.z = v4.z * v1.w;
    r1.w = r0.z * r0.x;
    r0.z = (uint)v4.w;
    r1.xyz = x0[r0.z+0].xyz;
    r0.y = 0.5;
    r0.xyzw = r1.xyzw * r0.xxxy;
    r1.xyzw = r3.xyzw * v1.xyzw + -r0.xyzw;
    r4.xyzw = r4.wwww * r1.xyzw + r0.xyzw;
  }
  r0.x = -0.00392156886 + r4.w;
  r0.x = cmp(r0.x < 0);
  if (r0.x != 0) discard;
  r0.xy = v6.xy + -v5.xw;
  r0.zw = -v6.xy + v5.zy;
  r0.xyzw = cmp(r0.xyzw < float4(0,0,0,0));
  r0.xy = (int2)r0.zw | (int2)r0.xy;
  r0.x = (int)r0.y | (int)r0.x;
  if (r0.x != 0) discard;
  r0.x = cmp(0.5 < w6.x);
  r0.y = cmp(g_model_time_PS >= -g_model_time_PS);
  r0.y = r0.y ? 1 : -1;
  r0.z = g_model_time_PS * r0.y;
  r0.z = frac(r0.z);
  r0.y = r0.y * r0.z;
  r0.y = 3.14159274 * r0.y;
  r0.y = sin(r0.y);
  r1.xyz = float3(0.25,0.25,0.25) * r4.xyz;
  r2.xyz = saturate(float3(3,3,3) * r4.xyz);
  r2.xyz = -r4.xyz * float3(0.25,0.25,0.25) + r2.xyz;
  r0.yzw = r0.yyy * r2.xyz + r1.xyz;
  r0.xyz = saturate(r0.xxx ? r0.yzw : r4.xyz);

  // UI-SLIDER
  r0.xyz *= ui_brightness / 80.f;

  r0.xyz = log2(r0.xyz);
  r0.xyz = customgamma * r0.xyz;
  r4.xyz = exp2(r0.xyz);
  o0.xyzw = r4.xyzw;
  return;
}