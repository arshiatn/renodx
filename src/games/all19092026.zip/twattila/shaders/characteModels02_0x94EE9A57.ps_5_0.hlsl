// ---- Created with 3Dmigoto v1.3.16 on Mon Aug 31 05:57:57 2026

cbuffer camera_VS_PS : register(b0)
{
  float3 camera_position : packoffset(c0);
  float4x4 view : packoffset(c1);
  float4x4 projection : packoffset(c5);
  float4x4 view_projection : packoffset(c9);
  float4x4 inv_view : packoffset(c13);
  float4x4 inv_projection : packoffset(c17);
  float4x4 inv_view_projection : packoffset(c21);
  float4 camera_near_far : packoffset(c25);
  float time_in_sec : packoffset(c26);
  float2 g_inverse_focal_length : packoffset(c26.y);
  float g_vertical_fov : packoffset(c26.w);
  float4 g_screen_size : packoffset(c27);
  float g_vpos_texel_offset : packoffset(c28);
  float4 g_viewport_dimensions : packoffset(c29);
  float4 g_render_target_dimensions : packoffset(c30);
  float4 g_camera_temp0 : packoffset(c31);
  float4 g_camera_temp1 : packoffset(c32);
  float4 g_camera_temp2 : packoffset(c33);
  float4 g_clip_rect : packoffset(c34);
  int g_num_of_samples : packoffset(c35);
}

cbuffer colorimetry_VS_PS : register(b1)
{
  float g_brightness : packoffset(c0);
  float g_gamma_output : packoffset(c0.y);
  float g_inv_gamma_output : packoffset(c0.z);
}

cbuffer constant_tone_mapping_buffer : register(b2)
{
  float g_luma_black_point : packoffset(c0);
  float g_luma_white_point : packoffset(c0.y);
  float g_luma_high_pass_threshold : packoffset(c0.z);
}

SamplerState g_hdr_rgb_texture_sampler_s : register(s0);
SamplerState g_hdr_rgb_bloom_texture_sampler_s : register(s1);
SamplerState g_scurve_texture_sampler_s : register(s2);
Texture2D<float4> g_hdr_rgb_texture_sampler : register(t0);
Texture2D<float4> g_hdr_rgb_bloom_texture_sampler : register(t1);
Texture2D<float4> g_scurve_texture_sampler : register(t2);
Texture2DMS<float> g_stencil_texture_ms : register(t3);


// 3Dmigoto declarations
#define cmp -
#include "../shared.h"


void main(
  float4 v0 : SV_Position0,
  float2 v1 : TEXCOORD0,
  out float4 o0 : SV_Target0)
{
  float4 r0,r1,r2;
  uint4 bitmask, uiDest;
  float4 fDest;
  float customGamma = 1 / 2.2f;

  r0.xy = g_vpos_texel_offset + v0.xy;
  r0.xy = g_screen_size.zw * r0.xy;
  r1.xyz = g_hdr_rgb_texture_sampler.SampleLevel(g_hdr_rgb_texture_sampler_s, r0.xy, 0).xyz;
  r0.xyz = g_hdr_rgb_bloom_texture_sampler.SampleLevel(g_hdr_rgb_bloom_texture_sampler_s, r0.xy, 0).xyz;
  r0.w = dot(r1.xyz, float3(0.212599993,0.715200007,0.0722000003));
  r1.w = g_luma_white_point + -g_luma_black_point;
  r2.x = r1.w * -0.340000004 + g_luma_white_point;
  r2.y = r2.x / r0.w;
  r0.w = cmp(r2.x < r0.w);
  r2.xyz = r2.yyy * r1.xyz;
  r1.xyz = r0.www ? r2.xyz : r1.xyz;
  r0.xyz = r1.xyz + r0.xyz;
  r0.w = max(r0.x, r0.y);
  r0.w = max(r0.w, r0.z);
  r1.xyz = r0.www + -r0.xyz;
  r0.w = dot(r0.xyz, float3(0.212599993,0.715200007,0.0722000003));
  r0.w = -g_luma_black_point + r0.w;
  r0.w = r0.w / r1.w;
  r0.w = -1 + r0.w;
  r0.w = saturate(1.17647052 * r0.w);
  r0.xyz = r0.www * r1.xyz + r0.xyz;
  r0.w = dot(r0.xyz, float3(0.212599993,0.715200007,0.0722000003));
  r1.x = max(g_luma_black_point, r0.w);
  r1.x = min(g_luma_white_point, r1.x);
  r1.x = -g_luma_black_point + r1.x;
  r1.x = r1.x / r1.w;
  r1.y = cmp(0 < r0.w);
  r0.w = 1 / r0.w;
  r0.w = r1.y ? r0.w : 1;
  r0.w = r1.x * r0.w;
  r0.xyz = saturate(r0.xyz * r0.www);
  r0.w = 0.5;
  r1.x = g_scurve_texture_sampler.Sample(g_scurve_texture_sampler_s, r0.xw).x;
  r1.x = saturate(r1.x);
  r1.y = g_scurve_texture_sampler.Sample(g_scurve_texture_sampler_s, r0.yw).y;
  r1.z = g_scurve_texture_sampler.Sample(g_scurve_texture_sampler_s, r0.zw).z;
  r1.yz = saturate(r1.yz);
  r0.xyz = log2(r1.xyz);
  r0.xyz = customGamma * r0.xyz;
  o0.xyz = exp2(r0.xyz);
  r0.xy = (int2)v0.xy;
  r0.zw = float2(0,0);
  r1.x = g_stencil_texture_ms.Load(r0.xy, 0).x;
  r1.y = g_stencil_texture_ms.Load(r0.xy, 1).x;
  r1.x = r1.x + r1.y;
  r1.y = g_stencil_texture_ms.Load(r0.xy, 2).x;
  r0.x = g_stencil_texture_ms.Load(r0.xy, 3).x;
  r0.y = r1.x + r1.y;
  r0.x = r0.y + r0.x;
  o0.w = 0.25 * r0.x;

  o0.xyz = renodx::color::gamma::DecodeSafe(o0.xyz);
  o0.xyz *= SI.graphics_white_nits / 80.f;
  o0.xyz = renodx::color::gamma::EncodeSafe(o0.xyz);
  return;
}